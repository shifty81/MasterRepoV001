# Compile-Ready Scaffold Pack

This pack adds compile-ready scaffolds for:

- `ProjectPathService`
- `EditorCommandRegistry`
- `MenuBarPanel`
- `ToolbarPanel`
- `EditorToolContext`
- `VoxelPickService`

## Intended integration targets

- `Source/Core/Paths/ProjectPathService.*`
- `Source/Editor/Commands/EditorCommandRegistry.*`
- `Source/Editor/Panels/MenuBarPanel.*`
- `Source/Editor/Panels/ToolbarPanel.*`
- `Source/Editor/Tools/EditorToolContext.h`
- `Source/Editor/Tools/VoxelPickService.*`

## What this solves

### ProjectPathService
Stops the editor and game from depending on the current working directory when resolving:
- `Config/novaforge.project.json`
- `Content/Definitions/DevWorld.json`

### EditorCommandRegistry
Creates one command layer for:
- menu actions
- toolbar actions
- hotkeys
- contextual actions later

### MenuBarPanel
Adds a real top menu definition with:
- File
- Edit
- View
- World
- Tools
- Help

### ToolbarPanel
Adds a real toolbar definition with:
- Save
- Reload
- Select
- Inspect
- Add
- Remove
- Debug
- Validate

### EditorToolContext
Defines the single source of truth for the active editor mode.

### VoxelPickService
Creates the integration point for viewport-to-voxel hit testing.

## Integration notes

### 1. Path resolution
At editor startup, initialize:

```cpp
nf::ProjectPathService pathService;
pathService.InitializeFrom(nf::ProjectPathService::GuessExecutableDirectory());
```

Then replace relative paths with:
- `pathService.GetManifestPath()`
- `pathService.GetDevWorldPath()`

### 2. Command registration
Instantiate `EditorCommandRegistry` once in the editor shell and register commands such as:
- `World.LoadDevWorld`
- `World.SaveDevWorld`
- `Tools.SelectMode`
- `Tools.VoxelInspectMode`
- `Tools.VoxelAddMode`
- `Tools.VoxelRemoveMode`

### 3. Menu and toolbar
Create both panels with the same registry instance, then call:
- `BuildDefaultMenus()`
- `BuildDefaultButtons()`

### 4. Tool routing
Store one `EditorToolContext` in `EditorApp` or equivalent. Update it only through tool commands.

### 5. Voxel picking
Call `VoxelPickService::PickVoxel(...)` from viewport mouse handling in:
- Select mode
- Voxel inspect mode
- Voxel add mode
- Voxel remove mode

## Status
These files are scaffolds. They are compile-ready, but not fully wired into your existing editor loop.
