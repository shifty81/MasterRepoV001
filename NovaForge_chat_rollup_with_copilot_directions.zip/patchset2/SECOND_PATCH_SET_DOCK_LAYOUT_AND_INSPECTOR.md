# SECOND_PATCH_SET_DOCK_LAYOUT_AND_INSPECTOR.md
This patch set is intended to apply **after** the first compile-ready patch set.
Validated in container by building `NovaForgeEditor` after applying patch set 1 and then this patch set.

## Files included

- `Source/Editor/Application/EditorApp.cpp`
- `Source/Editor/Panels/ContentBrowser.h`
- `Source/Editor/Panels/ContentBrowser.cpp`
- `Source/Editor/Panels/DockingSystem.h`
- `Source/Editor/Panels/DockingSystem.cpp`
- `Source/Editor/Panels/Inspector.h`
- `Source/Editor/Panels/Inspector.cpp`
- `Source/Editor/Viewport/EditorViewport.h`
- `Source/Editor/Viewport/EditorViewport.cpp`

## What this patch set changes

- adds cached dock panel content rects so layout can be queried before draw
- makes the editor viewport use the docked Viewport panel rect for sizing and input bounds
- wires ContentBrowser asset selection into Inspector
- clears inspector selection when navigating directories
- upgrades Inspector to display either entity data or selected asset metadata

## `Source/Editor/Application/EditorApp.cpp`

```diff
--- /mnt/data/repo_work_orig2/Source/Editor/Application/EditorApp.cpp	2026-04-02 22:38:24.677223070 +0000
+++ /mnt/data/repo_work/Source/Editor/Application/EditorApp.cpp	2026-04-02 22:43:23.987271170 +0000
@@ -334,6 +334,12 @@
     // Use manifest content root if available, else default
     m_ContentBrowser.SetRootPath(
         manifest.IsValid() ? manifest.ContentRoot : "Content");
+    m_ContentBrowser.SetOnAssetSelected([this](const std::string& assetPath) {
+        m_Inspector.SetSelectedAsset(assetPath);
+    });
+    m_ContentBrowser.SetOnDirectoryChanged([this]([[maybe_unused]] const std::string& path) {
+        m_Inspector.ClearSelection();
+    });
 
     // Register panels with the docking system — callbacks now forward bounds
     m_DockingSystem.RegisterPanel("SceneOutliner",
@@ -408,6 +414,19 @@
 
 void EditorApp::TickFrame(float dt)
 {
+    const float toolbarH = m_Toolbar.GetHeight() * m_DpiScale;
+    m_DockingSystem.BuildLayout(0.f, toolbarH,
+                                static_cast<float>(m_ClientWidth),
+                                static_cast<float>(m_ClientHeight) - toolbarH);
+
+    float viewportX = 0.f, viewportY = toolbarH;
+    float viewportW = static_cast<float>(m_ClientWidth);
+    float viewportH = static_cast<float>(m_ClientHeight) - toolbarH;
+    if (m_DockingSystem.GetPanelRect("Viewport", viewportX, viewportY, viewportW, viewportH)) {
+        m_Viewport.SetBounds(viewportX, viewportY, viewportW, viewportH);
+        m_Viewport.Resize(static_cast<int>(viewportW), static_cast<int>(viewportH));
+    }
+
     m_RenderDevice->BeginFrame();
     m_RenderDevice->Clear(0.18f, 0.18f, 0.18f, 1.f);
     m_Level.Update(dt);
@@ -438,7 +457,6 @@
     m_InteractionLoop.Tick(dt);
 
     // Toolbar strip at the top; docking fills the remaining area below.
-    const float toolbarH = m_Toolbar.GetHeight() * m_DpiScale;
     m_Toolbar.Draw(0.f, 0.f, static_cast<float>(m_ClientWidth), toolbarH);
     m_DockingSystem.Draw(0.f, toolbarH,
                          static_cast<float>(m_ClientWidth),

```

## `Source/Editor/Panels/ContentBrowser.h`

```diff
--- /mnt/data/repo_work_orig2/Source/Editor/Panels/ContentBrowser.h	2026-04-02 22:38:24.688377424 +0000
+++ /mnt/data/repo_work/Source/Editor/Panels/ContentBrowser.h	2026-04-02 22:43:22.349602887 +0000
@@ -1,5 +1,6 @@
 #pragma once
 #include "Editor/Application/EditorInputState.h"
+#include <functional>
 #include <string>
 #include <vector>
 
@@ -7,27 +8,20 @@
 
 namespace NF::Editor {
 
-/// @brief Panel for browsing project content assets.
 class ContentBrowser {
 public:
-    /// @brief Set the root directory to browse.
-    /// @param path Filesystem path to the content root.
-    void SetRootPath(std::string path) { m_RootPath = std::move(path); }
+    using AssetSelectedFn = std::function<void(const std::string&)>;
+    using DirectoryChangedFn = std::function<void(const std::string&)>;
 
-    /// @brief Set the UIRenderer used for drawing.
+    void SetRootPath(std::string path);
     void SetUIRenderer(UIRenderer* r) noexcept { m_Renderer = r; }
-
-    /// @brief Provide the current per-frame OS input state.
-    /// @param input Non-owning pointer updated by EditorApp each frame.
     void SetInputState(const EditorInputState* input) noexcept { m_Input = input; }
+    void SetOnAssetSelected(AssetSelectedFn fn) { m_OnAssetSelected = std::move(fn); }
+    void SetOnDirectoryChanged(DirectoryChangedFn fn) { m_OnDirectoryChanged = std::move(fn); }
 
-    /// @brief Advance panel state.
     void Update(float dt);
-
-    /// @brief Draw the content browser panel within the given region.
     void Draw(float x, float y, float w, float h);
 
-    /// @brief Return the path of the currently selected asset, or empty if none.
     [[nodiscard]] const std::string& GetSelectedAsset() const noexcept { return m_SelectedAsset; }
 
 private:
@@ -47,6 +41,8 @@
     bool                    m_Dirty{true};
     UIRenderer*             m_Renderer{nullptr};
     const EditorInputState* m_Input{nullptr};
+    AssetSelectedFn         m_OnAssetSelected;
+    DirectoryChangedFn      m_OnDirectoryChanged;
 };
 
 } // namespace NF::Editor

```

## `Source/Editor/Panels/ContentBrowser.cpp`

```diff
--- /mnt/data/repo_work_orig2/Source/Editor/Panels/ContentBrowser.cpp	2026-04-02 22:38:24.688083039 +0000
+++ /mnt/data/repo_work/Source/Editor/Panels/ContentBrowser.cpp	2026-04-02 22:43:22.360739474 +0000
@@ -6,6 +6,14 @@
 namespace NF::Editor {
 namespace fs = std::filesystem;
 
+void ContentBrowser::SetRootPath(std::string path)
+{
+    m_RootPath = std::move(path);
+    m_CurrentPath.clear();
+    m_SelectedAsset.clear();
+    m_Dirty = true;
+}
+
 void ContentBrowser::RefreshEntries()
 {
     m_Entries.clear();
@@ -47,6 +55,8 @@
     m_CurrentPath = path;
     m_SelectedAsset.clear();
     m_Dirty = true;
+    if (m_OnDirectoryChanged)
+        m_OnDirectoryChanged(m_CurrentPath);
 }
 
 void ContentBrowser::Update([[maybe_unused]] float dt)
@@ -55,7 +65,8 @@
         RefreshEntries();
 }
 
-void ContentBrowser::Draw(float x, float y, float w, float h) {
+void ContentBrowser::Draw(float x, float y, float w, float h)
+{
     if (!m_Renderer) return;
     if (m_Dirty) RefreshEntries();
 
@@ -71,12 +82,12 @@
 
     float cy = y + 4.f * dpi;
 
-    const std::string rootLabel = "Root: " + (m_RootPath.empty() ? "(none)" : m_RootPath);
-    m_Renderer->DrawText(rootLabel, x + padX, cy, kLabelColor, scale);
+    m_Renderer->DrawText("Root: " + (m_RootPath.empty() ? std::string("(none)") : m_RootPath),
+                         x + padX, cy, kLabelColor, scale);
     cy += lineH;
 
-    const std::string pathLabel = "Path: " + (m_CurrentPath.empty() ? "(none)" : m_CurrentPath);
-    m_Renderer->DrawText(pathLabel, x + padX, cy, kLabelColor, scale);
+    m_Renderer->DrawText("Path: " + (m_CurrentPath.empty() ? std::string("(none)") : m_CurrentPath),
+                         x + padX, cy, kLabelColor, scale);
     cy += lineH;
 
     if (!m_CurrentPath.empty() && m_CurrentPath != m_RootPath) {
@@ -117,6 +128,8 @@
                 return;
             }
             m_SelectedAsset = entry.FullPath;
+            if (m_OnAssetSelected)
+                m_OnAssetSelected(m_SelectedAsset);
         }
 
         const uint32_t rowColor = selected ? 0xFFFFFFFF : kTextColor;

```

## `Source/Editor/Panels/DockingSystem.h`

```diff
--- /mnt/data/repo_work_orig2/Source/Editor/Panels/DockingSystem.h	2026-04-02 22:38:24.682657787 +0000
+++ /mnt/data/repo_work/Source/Editor/Panels/DockingSystem.h	2026-04-02 22:43:22.304352824 +0000
@@ -8,69 +8,55 @@
 
 namespace NF::Editor {
 
-/// @brief Axis along which a dock node is split.
 enum class SplitAxis { Horizontal, Vertical };
 
-/// @brief A leaf or split node in the docking tree.
 struct DockNode {
-    uint32_t    id{0};          ///< Unique node identifier.
+    uint32_t    id{0};
     SplitAxis   axis{SplitAxis::Horizontal};
-    float       splitRatio{0.5f}; ///< Fraction [0,1] given to the first child.
+    float       splitRatio{0.5f};
     uint32_t    firstChild{0};
     uint32_t    secondChild{0};
-    std::string panelName;       ///< Non-empty only for leaf nodes.
+    std::string panelName;
     bool        isLeaf{true};
 };
 
-/// @brief Height in pixels of the panel title bar drawn by the docking system.
 constexpr float kPanelTitleBarHeight = 22.f;
 
-/// @brief Manages a tree of dockable panels inside the editor.
-///
-/// Panels register themselves by name; the system resolves layout
-/// at each frame and calls each panel's Draw() callback in the
-/// correct region.  When a UIRenderer is provided the system also
-/// draws panel chrome (background, border, title bar).
 class DockingSystem {
 public:
     using DrawFn = std::function<void(float x, float y, float w, float h)>;
 
+    struct PanelRect {
+        std::string name;
+        float x{0.f};
+        float y{0.f};
+        float w{0.f};
+        float h{0.f};
+    };
+
     DockingSystem() = default;
 
-    /// @brief Set the UIRenderer used for panel chrome.  May be nullptr.
     void SetUIRenderer(UIRenderer* renderer) noexcept { m_Renderer = renderer; }
-
-    /// @brief Register a named panel with its draw callback.
-    /// @param name   Unique panel name.
-    /// @param drawFn Called each frame with the panel's pixel region.
     void RegisterPanel(const std::string& name, DrawFn drawFn);
-
-    /// @brief Create a root horizontal split between two panels.
-    /// @param leftPanel   Panel name for the left region.
-    /// @param rightPanel  Panel name for the right region.
-    /// @param ratio       Fraction of total width given to the left panel.
     void SetRootSplit(const std::string& leftPanel,
                       const std::string& rightPanel,
                       float ratio = 0.25f);
-
-    /// @brief Split an existing leaf node into two children.
-    /// @param parentName Leaf panel to split.
-    /// @param newName    Panel name for the new sibling.
-    /// @param axis       Direction of the split.
-    /// @param ratio      Fraction of the parent region given to @p parentName.
     void SplitPanel(const std::string& parentName,
                     const std::string& newName,
                     SplitAxis axis,
                     float ratio = 0.5f);
-
-    /// @brief Advance any animated split transitions.
     void Update(float dt);
 
-    /// @brief Traverse the tree and invoke each panel's draw callback.
-    /// @param totalWidth  Available width in pixels.
-    /// @param totalHeight Available height in pixels.
+    /// Build and cache panel content rects for the current root region.
+    void BuildLayout(float x, float y, float totalWidth, float totalHeight);
+
+    /// Traverse the tree, draw panel chrome, and invoke each panel draw callback.
     void Draw(float x, float y, float totalWidth, float totalHeight);
 
+    /// Return the last computed content rect for a panel.
+    [[nodiscard]] bool GetPanelRect(const std::string& name,
+                                    float& x, float& y, float& w, float& h) const noexcept;
+
 private:
     struct PanelEntry {
         std::string name;
@@ -79,14 +65,16 @@
 
     std::vector<DockNode>   m_Nodes;
     std::vector<PanelEntry> m_Panels;
+    std::vector<PanelRect>  m_LastPanelRects;
     uint32_t                m_NextId{1};
     UIRenderer*             m_Renderer{nullptr};
 
     uint32_t    AllocNode();
     DockNode*   FindLeaf(const std::string& name);
-    void        DrawNode(const DockNode& node,
-                         float x, float y, float w, float h);
     DrawFn*     FindDrawFn(const std::string& name);
+    void        LayoutNode(const DockNode& node, float x, float y, float w, float h);
+    void        DrawNode(const DockNode& node, float x, float y, float w, float h);
+    void        CachePanelRect(const std::string& name, float x, float y, float w, float h);
 };
 
 } // namespace NF::Editor

```

## `Source/Editor/Panels/DockingSystem.cpp`

```diff
--- /mnt/data/repo_work_orig2/Source/Editor/Panels/DockingSystem.cpp	2026-04-02 22:38:24.682296777 +0000
+++ /mnt/data/repo_work/Source/Editor/Panels/DockingSystem.cpp	2026-04-02 22:43:22.315097536 +0000
@@ -2,19 +2,13 @@
 #include "UI/Rendering/UIRenderer.h"
 #include "Core/Logging/Log.h"
 #include <algorithm>
-#include <stdexcept>
 
 namespace NF::Editor {
 
-// --- Editor theme colours (0xRRGGBBAA) ---
-static constexpr uint32_t kPanelBgColor      = 0x2D2D30FF; // dark grey panel background
-static constexpr uint32_t kTitleBarBgColor    = 0x3C3C3CFF; // slightly lighter title bar
-static constexpr uint32_t kTitleTextColor     = 0xCCCCCCFF; // light grey text
-static constexpr uint32_t kPanelBorderColor   = 0x555555FF; // border between panels
-
-// ---------------------------------------------------------------------------
-// Helpers
-// ---------------------------------------------------------------------------
+static constexpr uint32_t kPanelBgColor     = 0x2D2D30FF;
+static constexpr uint32_t kTitleBarBgColor  = 0x3C3C3CFF;
+static constexpr uint32_t kTitleTextColor   = 0xCCCCCCFF;
+static constexpr uint32_t kPanelBorderColor = 0x555555FF;
 
 uint32_t DockingSystem::AllocNode()
 {
@@ -26,23 +20,35 @@
 
 DockNode* DockingSystem::FindLeaf(const std::string& name)
 {
-    for (auto& n : m_Nodes)
+    for (auto& n : m_Nodes) {
         if (n.isLeaf && n.panelName == name)
             return &n;
+    }
     return nullptr;
 }
 
 DockingSystem::DrawFn* DockingSystem::FindDrawFn(const std::string& name)
 {
-    for (auto& p : m_Panels)
+    for (auto& p : m_Panels) {
         if (p.name == name)
             return &p.drawFn;
+    }
     return nullptr;
 }
 
-// ---------------------------------------------------------------------------
-// Public API
-// ---------------------------------------------------------------------------
+void DockingSystem::CachePanelRect(const std::string& name, float x, float y, float w, float h)
+{
+    for (auto& entry : m_LastPanelRects) {
+        if (entry.name == name) {
+            entry.x = x;
+            entry.y = y;
+            entry.w = w;
+            entry.h = h;
+            return;
+        }
+    }
+    m_LastPanelRects.push_back(PanelRect{name, x, y, w, h});
+}
 
 void DockingSystem::RegisterPanel(const std::string& name, DrawFn drawFn)
 {
@@ -53,32 +59,27 @@
         }
     }
     m_Panels.push_back({name, std::move(drawFn)});
-    Logger::Log(LogLevel::Debug, "DockingSystem",
-                "Registered panel: " + name);
+    Logger::Log(LogLevel::Debug, "DockingSystem", "Registered panel: " + name);
 }
 
 void DockingSystem::SetRootSplit(const std::string& leftPanel,
-                                  const std::string& rightPanel,
-                                  float ratio)
+                                 const std::string& rightPanel,
+                                 float ratio)
 {
     m_Nodes.clear();
     m_NextId = 1;
 
-    // Root split node
     DockNode root{};
     root.id         = m_NextId++;
     root.isLeaf     = false;
     root.axis       = SplitAxis::Horizontal;
     root.splitRatio = std::clamp(ratio, 0.05f, 0.95f);
-    root.firstChild = m_NextId;      // will be set after
 
-    // Left leaf
     DockNode left{};
     left.id        = m_NextId++;
     left.isLeaf    = true;
     left.panelName = leftPanel;
 
-    // Right leaf
     DockNode right{};
     right.id        = m_NextId++;
     right.isLeaf    = true;
@@ -91,36 +92,31 @@
     m_Nodes.push_back(left);
     m_Nodes.push_back(right);
 
-    Logger::Log(LogLevel::Info, "DockingSystem",
-                "Root split: " + leftPanel + " | " + rightPanel);
+    Logger::Log(LogLevel::Info, "DockingSystem", "Root split: " + leftPanel + " | " + rightPanel);
 }
 
 void DockingSystem::SplitPanel(const std::string& parentName,
-                                const std::string& newName,
-                                SplitAxis axis,
-                                float ratio)
+                               const std::string& newName,
+                               SplitAxis axis,
+                               float ratio)
 {
     DockNode* leaf = FindLeaf(parentName);
     if (!leaf) {
-        Logger::Log(LogLevel::Warning, "DockingSystem",
-                    "SplitPanel: panel not found: " + parentName);
+        Logger::Log(LogLevel::Warning, "DockingSystem", "SplitPanel: panel not found: " + parentName);
         return;
     }
 
-    // Convert leaf into a split
-    std::string existingName = leaf->panelName;
+    const std::string existingName = leaf->panelName;
     leaf->isLeaf             = false;
     leaf->axis               = axis;
     leaf->splitRatio         = std::clamp(ratio, 0.05f, 0.95f);
     leaf->panelName.clear();
 
-    // First child keeps the original panel name
     DockNode first{};
     first.id        = m_NextId++;
     first.isLeaf    = true;
     first.panelName = existingName;
 
-    // Second child holds the new panel
     DockNode second{};
     second.id        = m_NextId++;
     second.isLeaf    = true;
@@ -132,75 +128,116 @@
     m_Nodes.push_back(first);
     m_Nodes.push_back(second);
 
-    Logger::Log(LogLevel::Info, "DockingSystem",
-                "Split '" + existingName + "' → '" + newName + "'");
+    Logger::Log(LogLevel::Info, "DockingSystem", "Split '" + existingName + "' → '" + newName + "'");
 }
 
 void DockingSystem::Update(float /*dt*/) {}
 
-void DockingSystem::DrawNode(const DockNode& node,
-                              float x, float y, float w, float h)
+void DockingSystem::LayoutNode(const DockNode& node, float x, float y, float w, float h)
 {
     if (node.isLeaf) {
-        // Draw panel chrome via UIRenderer if available
-        if (m_Renderer && w > 0.f && h > 0.f) {
-            const float dpi       = m_Renderer->GetDpiScale();
-            const float titleBarH = kPanelTitleBarHeight * dpi;
+        const float dpi       = m_Renderer ? m_Renderer->GetDpiScale() : 1.f;
+        const float titleBarH = kPanelTitleBarHeight * dpi;
+        const float contentY  = y + titleBarH;
+        const float contentH  = std::max(0.f, h - titleBarH);
+        CachePanelRect(node.panelName, x, contentY, w, contentH);
+        return;
+    }
 
-            // Panel background
-            m_Renderer->DrawRect({x, y, w, h}, kPanelBgColor);
+    const DockNode* first = nullptr;
+    const DockNode* second = nullptr;
+    for (const auto& n : m_Nodes) {
+        if (n.id == node.firstChild) first = &n;
+        if (n.id == node.secondChild) second = &n;
+    }
+    if (!first || !second) return;
 
-            // Title bar
-            m_Renderer->DrawRect({x, y, w, titleBarH}, kTitleBarBgColor);
+    if (node.axis == SplitAxis::Horizontal) {
+        const float leftW = w * node.splitRatio;
+        LayoutNode(*first,  x,         y, leftW,     h);
+        LayoutNode(*second, x + leftW, y, w - leftW, h);
+    } else {
+        const float topH = h * node.splitRatio;
+        LayoutNode(*first,  x, y,        w, topH);
+        LayoutNode(*second, x, y + topH, w, h - topH);
+    }
+}
+
+void DockingSystem::BuildLayout(float x, float y, float totalWidth, float totalHeight)
+{
+    m_LastPanelRects.clear();
+    if (m_Nodes.empty())
+        return;
+    LayoutNode(m_Nodes.front(), x, y, totalWidth, totalHeight);
+}
+
+bool DockingSystem::GetPanelRect(const std::string& name,
+                                 float& x, float& y, float& w, float& h) const noexcept
+{
+    for (const auto& rect : m_LastPanelRects) {
+        if (rect.name == name) {
+            x = rect.x;
+            y = rect.y;
+            w = rect.w;
+            h = rect.h;
+            return true;
+        }
+    }
+    return false;
+}
 
-            // Title text — scale 2 at 96 DPI; UIRenderer multiplies by DPI.
+void DockingSystem::DrawNode(const DockNode& node, float x, float y, float w, float h)
+{
+    if (node.isLeaf) {
+        const float dpi       = m_Renderer ? m_Renderer->GetDpiScale() : 1.f;
+        const float titleBarH = kPanelTitleBarHeight * dpi;
+        const float contentY  = y + titleBarH;
+        const float contentH  = std::max(0.f, h - titleBarH);
+        CachePanelRect(node.panelName, x, contentY, w, contentH);
+
+        if (m_Renderer && w > 0.f && h > 0.f) {
+            m_Renderer->DrawRect({x, y, w, h}, kPanelBgColor);
+            m_Renderer->DrawRect({x, y, w, titleBarH}, kTitleBarBgColor);
             if (!node.panelName.empty()) {
-                m_Renderer->DrawText(node.panelName,
-                                     x + 6.f * dpi, y + 4.f * dpi,
+                m_Renderer->DrawText(node.panelName, x + 6.f * dpi, y + 4.f * dpi,
                                      kTitleTextColor, 2.f);
             }
-
-            // Panel border
             m_Renderer->DrawOutlineRect({x, y, w, h}, kPanelBorderColor);
         }
 
-        // Call the panel's content draw callback with the content area
-        // (below the title bar).
         if (DrawFn* fn = FindDrawFn(node.panelName)) {
-            const float dpi       = m_Renderer ? m_Renderer->GetDpiScale() : 1.f;
-            const float titleBarH = kPanelTitleBarHeight * dpi;
-            const float contentY  = y + titleBarH;
-            const float contentH  = h - titleBarH;
             if (contentH > 0.f)
                 (*fn)(x, contentY, w, contentH);
         }
         return;
     }
 
-    // Find children
-    DockNode* first  = nullptr;
-    DockNode* second = nullptr;
-    for (auto& n : m_Nodes) {
-        if (n.id == node.firstChild)  first  = &n;
+    const DockNode* first = nullptr;
+    const DockNode* second = nullptr;
+    for (const auto& n : m_Nodes) {
+        if (n.id == node.firstChild) first = &n;
         if (n.id == node.secondChild) second = &n;
     }
     if (!first || !second) return;
 
     if (node.axis == SplitAxis::Horizontal) {
-        float leftW = w * node.splitRatio;
-        DrawNode(*first,  x,          y, leftW,      h);
-        DrawNode(*second, x + leftW,  y, w - leftW,  h);
+        const float leftW = w * node.splitRatio;
+        DrawNode(*first,  x,         y, leftW,     h);
+        DrawNode(*second, x + leftW, y, w - leftW, h);
     } else {
-        float topH = h * node.splitRatio;
-        DrawNode(*first,  x, y,          w, topH);
-        DrawNode(*second, x, y + topH,   w, h - topH);
+        const float topH = h * node.splitRatio;
+        DrawNode(*first,  x, y,        w, topH);
+        DrawNode(*second, x, y + topH, w, h - topH);
     }
 }
 
 void DockingSystem::Draw(float x, float y, float totalWidth, float totalHeight)
 {
-    if (m_Nodes.empty()) return;
-    DrawNode(m_Nodes[0], x, y, totalWidth, totalHeight);
+    if (m_Nodes.empty())
+        return;
+
+    m_LastPanelRects.clear();
+    DrawNode(m_Nodes.front(), x, y, totalWidth, totalHeight);
 }
 
 } // namespace NF::Editor

```

## `Source/Editor/Panels/Inspector.h`

```diff
--- /mnt/data/repo_work_orig2/Source/Editor/Panels/Inspector.h	2026-04-02 22:38:24.684689315 +0000
+++ /mnt/data/repo_work/Source/Editor/Panels/Inspector.h	2026-04-02 22:43:22.327584869 +0000
@@ -1,34 +1,29 @@
 #pragma once
 #include "Engine/ECS/World.h"
+#include <string>
 
 namespace NF { class UIRenderer; }
 
 namespace NF::Editor {
 
-/// @brief Panel that displays and edits components on the selected entity.
 class Inspector {
 public:
-    /// @brief Set the entity and world to inspect.
-    /// @param id    Entity to inspect; pass NullEntity to clear.
-    /// @param world World that owns the entity.
-    void SetSelectedEntity(EntityId id, World* world) noexcept {
-        m_SelectedEntity = id;
-        m_World          = world;
-    }
+    void SetSelectedEntity(EntityId id, World* world) noexcept;
+    void SetSelectedAsset(std::string assetPath);
+    void ClearSelection() noexcept;
 
-    /// @brief Set the UIRenderer used for drawing.
     void SetUIRenderer(UIRenderer* r) noexcept { m_Renderer = r; }
-
-    /// @brief Advance panel state.
     void Update(float dt);
-
-    /// @brief Draw all components of the selected entity within the given region.
     void Draw(float x, float y, float w, float h);
 
 private:
-    EntityId     m_SelectedEntity{NullEntity};
-    World*       m_World{nullptr};
-    UIRenderer*  m_Renderer{nullptr};
+    enum class SelectionMode { None, Entity, Asset };
+
+    SelectionMode m_Mode{SelectionMode::None};
+    EntityId      m_SelectedEntity{NullEntity};
+    World*        m_World{nullptr};
+    std::string   m_SelectedAsset;
+    UIRenderer*   m_Renderer{nullptr};
 };
 
 } // namespace NF::Editor

```

## `Source/Editor/Panels/Inspector.cpp`

```diff
--- /mnt/data/repo_work_orig2/Source/Editor/Panels/Inspector.cpp	2026-04-02 22:38:24.684357342 +0000
+++ /mnt/data/repo_work/Source/Editor/Panels/Inspector.cpp	2026-04-02 22:43:22.338299448 +0000
@@ -1,12 +1,39 @@
 #include "Editor/Panels/Inspector.h"
 #include "UI/Rendering/UIRenderer.h"
+#include <filesystem>
 #include <string>
 
 namespace NF::Editor {
+namespace fs = std::filesystem;
+
+void Inspector::SetSelectedEntity(EntityId id, World* world) noexcept
+{
+    m_Mode = SelectionMode::Entity;
+    m_SelectedEntity = id;
+    m_World = world;
+    m_SelectedAsset.clear();
+}
+
+void Inspector::SetSelectedAsset(std::string assetPath)
+{
+    m_Mode = SelectionMode::Asset;
+    m_SelectedEntity = NullEntity;
+    m_World = nullptr;
+    m_SelectedAsset = std::move(assetPath);
+}
+
+void Inspector::ClearSelection() noexcept
+{
+    m_Mode = SelectionMode::None;
+    m_SelectedEntity = NullEntity;
+    m_World = nullptr;
+    m_SelectedAsset.clear();
+}
 
 void Inspector::Update([[maybe_unused]] float dt) {}
 
-void Inspector::Draw(float x, float y, float w, float h) {
+void Inspector::Draw(float x, float y, float w, float h)
+{
     if (!m_Renderer) return;
     (void)w; (void)h;
 
@@ -16,15 +43,34 @@
     const float lineH = 20.f * dpi;
     const float padX  = 6.f * dpi;
     const float scale = 2.f;
+    float cy = y + 4.f * dpi;
+
+    if (m_Mode == SelectionMode::Asset && !m_SelectedAsset.empty()) {
+        const fs::path path(m_SelectedAsset);
+        const bool exists = fs::exists(path);
+        const bool isDir  = exists && fs::is_directory(path);
+
+        m_Renderer->DrawText("Selected Asset", x + padX, cy, kTextColor, scale);
+        cy += lineH;
+        m_Renderer->DrawText("Name: " + path.filename().generic_string(), x + padX, cy, kLabelColor, scale);
+        cy += lineH;
+        m_Renderer->DrawText("Type: " + std::string(isDir ? "Folder" : "File"), x + padX, cy, kLabelColor, scale);
+        cy += lineH;
+        m_Renderer->DrawText("Path:", x + padX, cy, kLabelColor, scale);
+        cy += lineH;
+        m_Renderer->DrawText(path.generic_string(), x + padX, cy, kTextColor, 1.5f);
+        return;
+    }
 
-    if (m_SelectedEntity == NullEntity || !m_World) {
-        m_Renderer->DrawText("No entity selected", x + padX, y + 4.f * dpi, kLabelColor, scale);
+    if (m_Mode == SelectionMode::Entity && m_SelectedEntity != NullEntity && m_World) {
+        const std::string label = "Entity " + std::to_string(m_SelectedEntity);
+        m_Renderer->DrawText(label, x + padX, cy, kTextColor, scale);
+        cy += lineH;
+        m_Renderer->DrawText("Components:", x + padX, cy, kLabelColor, scale);
         return;
     }
 
-    std::string label = "Entity " + std::to_string(m_SelectedEntity);
-    m_Renderer->DrawText(label,        x + padX, y + 4.f  * dpi,           kTextColor,  scale);
-    m_Renderer->DrawText("Components:", x + padX, y + 4.f  * dpi + lineH,  kLabelColor, scale);
+    m_Renderer->DrawText("No selection", x + padX, cy, kLabelColor, scale);
 }
 
 } // namespace NF::Editor

```

## `Source/Editor/Viewport/EditorViewport.h`

```diff
--- /mnt/data/repo_work_orig2/Source/Editor/Viewport/EditorViewport.h	2026-04-02 22:38:24.688719549 +0000
+++ /mnt/data/repo_work/Source/Editor/Viewport/EditorViewport.h	2026-04-02 22:43:22.371914330 +0000
@@ -8,36 +8,17 @@
 
 namespace NF::Editor {
 
-/// @brief 3-D viewport with an orbit camera.
 class EditorViewport {
 public:
-    /// @brief Initialise the viewport with the given render device.
-    /// @param device Non-owning pointer; must outlive this viewport.
     void Init(RenderDevice* device);
-
-    /// @brief Set the UIRenderer used for drawing overlays.
     void SetUIRenderer(UIRenderer* r) noexcept { m_Renderer = r; }
-
-    /// @brief Provide the current per-frame OS input state.
-    /// @param input Non-owning pointer updated by EditorApp each frame.
     void SetInputState(const EditorInputState* input) noexcept { m_Input = input; }
-
-    /// @brief Resize the viewport framebuffer.
-    /// @param width  New width in pixels.
-    /// @param height New height in pixels.
     void Resize(int width, int height);
-
-    /// @brief Advance camera state using mouse/keyboard input.
-    /// @param dt Delta time in seconds.
+    void SetBounds(float x, float y, float w, float h) noexcept;
     void Update(float dt);
-
-    /// @brief Issue draw calls for this viewport within the given region.
     void Draw(float x, float y, float w, float h);
 
-    /// @brief Return the current view matrix.
     [[nodiscard]] Matrix4x4 GetViewMatrix() const noexcept;
-
-    /// @brief Return the current projection matrix.
     [[nodiscard]] Matrix4x4 GetProjectionMatrix() const noexcept;
 
 private:
@@ -48,13 +29,11 @@
     int   m_Width{1280};
     int   m_Height{720};
 
-    // Orbit camera state
-    float   m_Pitch{0.3f};   ///< Vertical angle (radians, clamped).
-    float   m_Yaw{0.f};      ///< Horizontal angle (radians).
-    float   m_Zoom{5.f};     ///< Distance from target.
-    Vector3 m_Target{};      ///< Orbit pivot point.
+    float   m_Pitch{0.3f};
+    float   m_Yaw{0.f};
+    float   m_Zoom{5.f};
+    Vector3 m_Target{};
 
-    // Cached viewport bounds (set each Draw call, read in Update).
     float m_BoundsX{0.f};
     float m_BoundsY{0.f};
     float m_BoundsW{0.f};

```

## `Source/Editor/Viewport/EditorViewport.cpp`

```diff
--- /mnt/data/repo_work_orig2/Source/Editor/Viewport/EditorViewport.cpp	2026-04-02 22:38:24.689692380 +0000
+++ /mnt/data/repo_work/Source/Editor/Viewport/EditorViewport.cpp	2026-04-02 22:43:22.383095702 +0000
@@ -7,27 +7,33 @@
 
 namespace NF::Editor {
 
-// Camera sensitivity constants
-static constexpr float kOrbitSensitivity = 0.005f; // radians per pixel
-static constexpr float kPanSensitivity   = 0.003f; // world units per pixel per unit zoom
-static constexpr float kZoomSensitivity  = 0.12f;  // fraction of current zoom per wheel tick
+static constexpr float kOrbitSensitivity = 0.005f;
+static constexpr float kPanSensitivity   = 0.003f;
+static constexpr float kZoomSensitivity  = 0.12f;
 static constexpr float kMinZoom          = 0.2f;
 static constexpr float kMaxZoom          = 500.f;
-static constexpr float kMaxPitch         = 1.55f;  // ~89 degrees (avoid gimbal lock)
+static constexpr float kMaxPitch         = 1.55f;
 
 void EditorViewport::Init(RenderDevice* device) {
     m_Device = device;
 }
 
 void EditorViewport::Resize(int width, int height) {
-    m_Width  = std::max(width, 1);
-    m_Height = std::max(height, 1);
+    m_Width  = std::max(1, width);
+    m_Height = std::max(1, height);
+}
+
+void EditorViewport::SetBounds(float x, float y, float w, float h) noexcept
+{
+    m_BoundsX = x;
+    m_BoundsY = y;
+    m_BoundsW = w;
+    m_BoundsH = h;
 }
 
 void EditorViewport::Update([[maybe_unused]] float dt) {
     if (!m_Input || m_BoundsW <= 0.f || m_BoundsH <= 0.f) return;
 
-    // Only respond when the cursor is inside the viewport panel.
     const bool inViewport =
         m_Input->mouseX >= m_BoundsX && m_Input->mouseX < m_BoundsX + m_BoundsW &&
         m_Input->mouseY >= m_BoundsY && m_Input->mouseY < m_BoundsY + m_BoundsH;
@@ -37,16 +43,13 @@
     const float dx = m_Input->mouseDeltaX;
     const float dy = m_Input->mouseDeltaY;
 
-    // --- Orbit: right mouse drag ---
     if (m_Input->rightDown && (dx != 0.f || dy != 0.f)) {
         m_Yaw   += dx * kOrbitSensitivity;
-        m_Pitch -= dy * kOrbitSensitivity; // invert Y for natural feel
+        m_Pitch -= dy * kOrbitSensitivity;
         m_Pitch  = std::clamp(m_Pitch, -kMaxPitch, kMaxPitch);
     }
 
-    // --- Pan: middle mouse drag ---
     if (m_Input->middleDown && (dx != 0.f || dy != 0.f)) {
-        // Build camera right and up axes from current yaw/pitch.
         const float cp = std::cos(m_Pitch);
         const float sp = std::sin(m_Pitch);
         const float cy = std::cos(m_Yaw);
@@ -55,12 +58,10 @@
         Vector3 right  = Vector3{ cy, 0.f, -sy }.Normalized();
         Vector3 camUp  = Vector3{ sp * sy, cp, sp * cy }.Normalized();
 
-        // Scale pan speed with zoom so distant scenes pan at a natural rate.
         const float panScale = kPanSensitivity * m_Zoom;
         m_Target = m_Target - right * (dx * panScale) + camUp * (dy * panScale);
     }
 
-    // --- Zoom: mouse wheel ---
     if (m_Input->wheelDelta != 0.f) {
         m_Zoom *= 1.f - m_Input->wheelDelta * kZoomSensitivity;
         m_Zoom  = std::clamp(m_Zoom, kMinZoom, kMaxZoom);
@@ -68,13 +69,7 @@
 }
 
 void EditorViewport::Draw(float x, float y, float w, float h) {
-    // Cache bounds so Update() can do mouse-in-viewport testing.
-    m_BoundsX = x;
-    m_BoundsY = y;
-    m_BoundsW = w;
-    m_BoundsH = h;
-    m_Width   = std::max(1, static_cast<int>(w));
-    m_Height  = std::max(1, static_cast<int>(h));
+    SetBounds(x, y, w, h);
 
     if (!m_Renderer) return;
 
@@ -85,7 +80,6 @@
 
     m_Renderer->DrawRect({x, y, w, h}, kViewportBg);
 
-    // Grid overlay — scale grid spacing with DPI.
     const float dpi         = m_Renderer->GetDpiScale();
     const float gridSpacing = 40.f * dpi;
     for (float gx = x + gridSpacing; gx < x + w; gx += gridSpacing)
@@ -93,17 +87,12 @@
     for (float gy = y + gridSpacing; gy < y + h; gy += gridSpacing)
         m_Renderer->DrawRect({x, gy, w, 1.f}, kGridLineColor);
 
-    // Center label
     m_Renderer->DrawText("3D Viewport",
                          x + w * 0.5f - 44.f * dpi,
                          y + h * 0.5f - 7.f  * dpi,
                          kLabelColor, 2.f);
 
-    // Camera info overlay (bottom-left corner of viewport).
-    // Converts pitch/yaw to degrees for readability.
     const float padX = 6.f * dpi;
-    const float padY = 6.f * dpi;
-
     auto toDeg = [](float rad) -> int {
         return static_cast<int>(rad * (180.f / std::numbers::pi_v<float>));
     };
@@ -117,7 +106,6 @@
 }
 
 Matrix4x4 EditorViewport::GetViewMatrix() const noexcept {
-    // Build simple orbit look-at from pitch/yaw/zoom.
     const float cp = std::cos(m_Pitch), sp = std::sin(m_Pitch);
     const float cy = std::cos(m_Yaw),  sy = std::sin(m_Yaw);
     Vector3 eye{
@@ -140,10 +128,9 @@
 }
 
 Matrix4x4 EditorViewport::GetProjectionMatrix() const noexcept {
-    // Perspective projection (45° FOV, near=0.1, far=1000).
     const float aspect = (m_Height > 0)
         ? static_cast<float>(m_Width) / static_cast<float>(m_Height) : 1.f;
-    const float fovY  = 0.7854f; // ~45 degrees in radians
+    const float fovY  = 0.7854f;
     const float nearZ = 0.1f, farZ = 1000.f;
     const float f     = 1.f / std::tan(fovY * 0.5f);
 

```

