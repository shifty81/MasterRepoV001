# EDITOR_CONTROL_SCHEMA_AND_ASSET_MODEL_EDITOR.md

## Purpose
Define the near-term control model and editor interaction rules for NovaForge so the current custom editor behaves like a practical Unreal-style sandbox editor without copying Unreal directly.

This is a design file. It does not claim these features are fully implemented now.

## Current reality

What is partially real now:
- docked editor shell
- custom UI renderer
- content browser selection and inspector wiring
- viewport camera orbit, pan, zoom
- dev-world bootstrap with generated chunks
- voxel chunk meshing and rendering path

What is still missing or incomplete:
- strong asset open routing
- dedicated model editor mode
- dedicated asset editor mode
- true editor tool modes
- proper voxel authoring workflow
- stable Phase 1 save and reload loop
- validated Phase 2 authoring and runtime integrity loop

## Control schema

### Core viewport controls

These should be the default and should stay stable long term.

- `RMB drag`: orbit camera
- `MMB drag`: pan camera
- `Mouse wheel`: zoom camera
- `F`: focus selection
- `W`: translate tool
- `E`: rotate tool
- `R`: scale tool
- `Q`: select / no gizmo
- `Delete`: delete selected editor object
- `Ctrl+D`: duplicate selected editor object
- `Ctrl+S`: save active world or asset
- `Ctrl+Shift+S`: save all dirty assets
- `Ctrl+P`: quick-open asset
- `Space`: cycle transform gizmo mode

### Viewport click behavior

Single click:
- select actor, voxel target, or asset preview target depending on mode

Double click:
- focus selected object
- for content browser assets, open in the matching asset editor

Drag behavior:
- with gizmo active, drag manipulates selected object
- with no gizmo active and empty-space drag, camera interaction wins

### Editor modes

The editor should have explicit top-level modes.

- `World`
- `Voxel`
- `Model`
- `Asset`
- `Play`

Mode switches should be visible in the toolbar and mirrored in status text in the viewport.

## World mode

Purpose:
- inspect and place world objects
- load the Phase 1 dev world
- validate spawn path and dev-zone baseline

User flow:
1. open editor
2. dev world loads automatically
3. viewport shows stable sandbox scene
4. scene outliner selects entities
5. inspector edits entity transforms and world metadata
6. save writes back dev world state

Must show:
- world name
- seed
- spawn point
- loaded chunk count
- save state dirty/clean

## Voxel mode

Purpose:
- inspect chunk content
- select chunk under cursor
- perform voxel edits later in Phase 2

User flow:
1. switch to voxel mode
2. voxel inspector shows selected chunk and stats
3. click or hover in viewport selects voxel target
4. edit tools later add place/remove/repair operations
5. chunk integrity validation is available from toolbar or inspector

Must show:
- chunk coord
- chunk loaded state
- dirty state
- triangle count
- serialization status

## Model editor

Purpose:
- edit a single model asset in isolation
- inspect mesh hierarchy, sockets, materials, collision proxy, LOD setup

### How it interacts with the main editor

- opens as a dedicated tab or docked panel set
- launched by double-clicking a model asset from Content Browser
- does not replace the whole app
- uses the same viewport camera controls as the main world viewport
- can preview against neutral background or dev-world lighting profile

### Model editor layout

Left:
- asset tree or submesh list

Center:
- model viewport

Right:
- properties inspector

Bottom:
- build/messages/material slots/LOD summary

### Model editor user actions

- orbit, pan, zoom preview camera
- inspect mesh sections
- assign materials
- define sockets
- preview simple collision
- toggle normals, wireframe, bounds, pivot
- view LOD transitions
- save asset

### Model editor save behavior

Saving updates the source asset metadata and marks dependent previews dirty.

## Asset editor

Purpose:
- one routing layer for all non-world asset editing

### Asset types in scope

Phase 1 and 2 practical minimum:
- definitions
- materials
- textures
- static models
- voxel presets later

### Asset editor manager behavior

Double-click in Content Browser should route by type:
- `.json` definition -> definition editor
- texture -> texture inspector/editor
- mesh/model -> model editor
- material -> material editor
- unknown -> metadata inspector fallback

### Asset editor interaction model

Every asset editor should support:
- save
- revert
- dirty marker
- source path display
- dependency list later

## Visual polish with current custom UI only

No new UI framework needed.

Near-term improvements that fit the current renderer:
- stronger panel title bars with accent lines
- subtle translucent panel content shading
- viewport top and bottom info strips
- clip-correct panel drawing
- consistent slate-blue accent color
- brighter text hierarchy
- status badges for mode and world readiness

## Phase 1 recovery map

### Goal
One stable dev world for early testing.

### Required proof
- dev world auto-loads from editor boot
- visible world exists in viewport
- spawn path is controlled
- seed is fixed and visible
- save/load hook exists and can be exercised
- debug overlay reports honest state

### Still needed
- explicit world save action in toolbar
- load last dev-world save option
- spawn marker visualization
- world properties section in inspector

## Phase 2 recovery map

### Goal
Authoritative voxel runtime.

### Required proof
- chunk data model exists
- chunk streaming rules are testable
- voxel storage and indexing behave correctly
- voxel edit operations can be invoked in editor
- mining/damage hooks modify chunk data
- voxel serialization round-trips
- chunk integrity validation is runnable

### Still needed
- viewport voxel picking
- place/remove voxel tools in voxel mode
- save/reload validation button
- per-chunk dirty and serialized state in inspector
- editor-side chunk reload command

## Immediate next implementation order

1. asset editor manager
2. model editor panel
3. world properties inspector for dev world
4. voxel mode tool routing
5. save/load commands in toolbar
6. viewport selection ray and voxel picking

## Honest status

Your current editor shell is good enough to stabilize and test against after the third patch set. It is not yet a complete world editor or a complete voxel authoring editor.
