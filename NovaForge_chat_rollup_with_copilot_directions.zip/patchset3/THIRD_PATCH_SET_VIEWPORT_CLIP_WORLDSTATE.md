# THIRD_PATCH_SET_VIEWPORT_CLIP_WORLDSTATE.md
This patch set is intended to apply **after** the first and second compile-ready patch sets.
Validated in the container by building `NovaForgeEditor` after applying this patch set on top of the prior two patch sets.

## Files included

- `Source/Renderer/RHI/RenderDevice.h`
- `Source/Renderer/RHI/RenderDevice.cpp`
- `Source/UI/Rendering/UIRenderer.h`
- `Source/UI/Rendering/UIRenderer.cpp`
- `Source/Editor/Application/EditorApp.h`
- `Source/Editor/Application/EditorApp.cpp`
- `Source/Editor/Viewport/EditorViewport.cpp`
- `Source/Editor/Panels/DockingSystem.cpp`
- `Source/Editor/Panels/HUDPanel.h`
- `Source/Editor/Panels/HUDPanel.cpp`
- `Source/Game/World/GameWorld.h`
- `Source/Game/World/GameWorld.cpp`

## What this patch set changes

- adds viewport sub-rect rendering support through `RenderDevice` viewport and scissor APIs
- renders the 3D scene only inside the docked `Viewport` panel rect
- restores full-window UI rendering after the 3D viewport pass
- adds a `UIRenderer` clip stack so panel content is clipped to its content rect
- uses clip rects in `DockingSystem` so panel child widgets stop bleeding into neighboring panels
- removes the opaque viewport fill that was covering the rendered 3D scene
- upgrades viewport chrome with a more readable status-strip style using the current custom UI renderer only
- adds honest world bootstrap state and counts to `GameWorld`
- adds runtime render-state logging in `EditorApp`
- exposes world readiness in `HUDPanel`

## Validation

Build command used:

```bash
cmake --build . --target NovaForgeEditor -j2
```

Result:
- `NovaForgeEditor` built successfully in the container

## Limits of this patch set

This does **not** yet add:
- true render-to-texture viewport composition
- gizmo hit proxies
- a model editor panel
- an asset editor manager
- dev-world property authoring UI
- voxel authoring workflows beyond the current runtime plumbing

This patch set stabilizes the existing editor shell so Phase 1 and Phase 2 work can be tested more honestly.
