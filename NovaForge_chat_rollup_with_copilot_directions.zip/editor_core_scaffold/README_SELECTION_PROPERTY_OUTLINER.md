# Selection + Property Inspector + World Outliner Scaffold Pack

This pack adds compile-ready scaffolds for:
- `SelectionService`
- `PropertyInspectorSystem`
- `WorldOutlinerPanel`

## Purpose

These three systems close a major gap between the current NovaForge editor shell and a real editor workflow.

They provide:
- one authoritative editor selection model
- one structured property inspection layer
- one world hierarchy/outliner panel

## What this pack does

### SelectionService
Creates one shared source of truth for editor selection:
- none
- asset
- world object
- chunk
- voxel

### PropertyInspectorSystem
Creates a typed property model that the inspector can render:
- bool
- int
- float
- string
- vec3

This is a scaffold for property display and editing integration.

### WorldOutlinerPanel
Creates a structured tree model for the world:
- root node
- chunk or test world nodes
- generic children later

## What this pack does not do yet

- full runtime data binding
- true reflection
- real scene/entity tree extraction
- actual property editing widgets
- viewport-to-selection synchronization
- drag/drop reordering
- undo transactions

## Recommended next integration
- bind `SelectionService` into Content Browser, Inspector, and Viewport
- feed `PropertyInspectorSystem` from selected object metadata
- feed `WorldOutlinerPanel` from DevWorld state
