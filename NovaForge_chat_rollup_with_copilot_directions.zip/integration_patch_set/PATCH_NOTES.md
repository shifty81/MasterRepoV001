# Patch Notes

## Wire order

1. Add the scaffold pack files first.
2. Replace your current `EditorApp.*` with the versions in this pack or merge the relevant sections.
3. Replace your current `EditorViewport.*` with the versions in this pack or merge the relevant sections.
4. Add the new headers to your project build files.
5. Build the editor.
6. Confirm the editor boot log prints:
   - current path
   - repo root
   - manifest path
   - content root
   - DevWorld path
   - existence checks
7. Trigger commands through menu or toolbar wiring.
8. Confirm viewport input switches behavior by active tool mode.

## What still remains

- real menu dropdown rendering
- real toolbar button rendering
- real hotkey dispatch
- real camera and world references in `EditorViewport`
- real `VoxelPickService` voxel raymarch logic
- real world load/save implementation behind the command handlers
