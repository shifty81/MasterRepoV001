# Integration Patch Set

This patch set wires these systems into the editor shell:

- `ProjectPathService` into editor boot
- `EditorCommandRegistry` into `EditorApp`
- `MenuBarPanel` and `ToolbarPanel` into the shell
- `EditorToolContext` into viewport input
- `VoxelPickService` into voxel inspect/add/remove mode

## Included files

- `Source/Editor/Application/EditorApp.h`
- `Source/Editor/Application/EditorApp.cpp`
- `Source/Editor/Viewport/EditorViewport.h`
- `Source/Editor/Viewport/EditorViewport.cpp`

## Assumptions

This patch set assumes you already added the earlier scaffold files:
- `Source/Core/Paths/ProjectPathService.*`
- `Source/Editor/Commands/EditorCommandRegistry.*`
- `Source/Editor/Panels/MenuBarPanel.*`
- `Source/Editor/Panels/ToolbarPanel.*`
- `Source/Editor/Tools/EditorToolContext.h`
- `Source/Editor/Tools/VoxelPickService.*`

## What this patch does

### Editor boot
- resolves the repo root through `ProjectPathService`
- logs manifest and DevWorld locations
- prevents blind relative-path lookup

### Editor shell
- creates one `EditorCommandRegistry`
- registers world, tool, and view commands
- creates `MenuBarPanel`
- creates `ToolbarPanel`

### Viewport input
- stores one `EditorToolContext`
- routes mouse input by active tool mode
- uses `VoxelPickService` in voxel modes

## Notes

This is still a compile-ready scaffold patch. It establishes the correct integration seams and wiring pattern, but it does not implement full UI rendering for menu dropdowns or toolbar buttons. It gives the editor one place to own command state, tool state, and path truth.

`VoxelPickService` remains a stub unless you replace it with real voxel raymarch logic.
