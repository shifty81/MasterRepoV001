# EDITOR_CONTROL_AND_PHASE_RECOVERY_PLAN.md

## Scope
This document defines the next editor stabilization layer for NovaForge:
- viewport sub-rect rendering
- clip/scissor correction
- honest world-state logging
- Unreal-like editor control schema
- minimal visual polish using the current custom UI stack
- Model Editor definition
- Asset Editor definition
- Phase 1 and Phase 2 recovery plan tied to the current repo

This is scoped to the standalone NovaForge repo only.

---

## 1. Current State Diagnosis

Based on the current source and the screenshots, the editor is not fully failing. It is partially wired.

What is working:
- custom panel layout exists
- content browser enumerates the filesystem
- inspector can display selected asset metadata
- viewport camera orbit/pan/zoom logic exists
- fallback dev world generates a small chunk set in memory
- voxel stats/debug hooks exist

What is not working correctly:
- viewport is still a fake panel draw, not a true 3D sub-rect render target
- UI has no clip stack or scissor stack, so panel content can overdraw freely
- world logging reports descriptor load too early relative to visible state
- editor and runtime state are not expressed as separate readiness stages
- content interaction is basic and lacks asset-type-aware editing
- style is functional but flat and visually weak
- Phase 1 and Phase 2 systems are only partially connected end-to-end

Bluntly: the repo has pieces of the intended architecture, but not the full control loop.

---

## 2. Third Patch Set Design

### 2.1 Viewport sub-rect rendering

### Goal
The viewport panel must render the world only inside the docked viewport content rect, not as a whole-window assumption.

### Current problem
`EditorViewport::Draw()` currently paints a flat placeholder grid and text overlay. It does not own or drive a real scene sub-viewport. `UIRenderer` also has no clipping API. The renderer path underneath still behaves like a global framebuffer path.

### Required architecture
Add a dedicated editor viewport render path with this flow:

1. `DockingSystem` computes the viewport content rect.
2. `EditorApp` reads the viewport panel rect each frame.
3. `EditorViewport` stores that rect as the authoritative render region.
4. `RenderDevice` receives a viewport/scissor command for that region.
5. World rendering occurs only inside that rect.
6. UI overlays are then drawn on top.

### Required data contract
```cpp
struct ViewportRect
{
    int x;
    int y;
    int width;
    int height;
};
```

### Required methods
- `EditorViewport::SetRenderRect(ViewportRect)`
- `RenderDevice::SetViewport(int x, int y, int w, int h)`
- `RenderDevice::SetScissor(int x, int y, int w, int h)`
- `RenderDevice::ClearViewportRegion(...)`
- `EditorApp::RenderEditorViewport()`

### Frame order
```text
Begin frame
  Build dock layout
  Query viewport panel rect
  Set 3D viewport/scissor to panel rect
  Render world scene into viewport rect
  Restore full-window viewport
  Begin UI frame
  Draw panel chrome
  Draw panel contents
  Draw viewport overlay labels/gizmos
End frame
```

### Done condition
- resizing the window updates the viewport render region
- the 3D scene stays inside the viewport panel
- no scene draw spills into inspector, console, or content browser

---

### 2.2 Clip/scissor correction

### Goal
Every panel must respect its own content bounds.

### Current problem
`UIRenderer` only batches quads and text. It has no clip stack. Panels therefore rely on manual draw restraint.

### Required design
Add a clip stack to `UIRenderer`.

### New API
```cpp
void PushClipRect(const Rect& rect);
void PopClipRect();
```

### Internal behavior
- maintain a stack of clip rects
- intersect nested clip rects
- flush current batch before clip-state change
- enable GL scissor while drawing the batch

### Required source targets
- `Source/UI/Rendering/UIRenderer.h`
- `Source/UI/Rendering/UIRenderer.cpp`
- `Source/Editor/Panels/DockingSystem.cpp`
- `Source/Editor/Panels/ContentBrowser.cpp`
- `Source/Editor/Panels/Inspector.cpp`
- `Source/Editor/Panels/ConsolePanel.cpp`
- `Source/Editor/Panels/SceneOutliner.cpp`
- `Source/Editor/Panels/VoxelInspector.cpp`

### Panel usage pattern
```cpp
m_Renderer->PushClipRect({x, y, w, h});
// draw rows, labels, buttons, trees
m_Renderer->PopClipRect();
```

### Done condition
- long file paths do not bleed into adjacent panels
- console text stays inside console panel
- content browser entries stop at panel boundary
- viewport overlay text stays inside viewport rect

---

### 2.3 Honest world-state logging

### Goal
The editor must report exact readiness stages, not implied success.

### Current problem
The repo logs that the world definition loaded and that chunks were generated. That is better than before, but it still does not separate:
- world descriptor loaded
- simulation world created
- chunk data generated
- meshes built
- render submission completed
- viewport visible state ready

### Required state model
```cpp
enum class WorldBootStage
{
    None,
    DefinitionLoaded,
    FallbackApplied,
    SpawnReady,
    ChunkDataReady,
    MeshesReady,
    RenderProxyReady,
    ViewportVisible
};
```

### Required logs
```text
[World] Definition loaded: DevWorld
[World] Fallback applied: YES/NO
[World] Spawn ready: x y z
[World] Chunk data generated: N
[World] Meshes built: N
[World] Render proxies uploaded: N
[Viewport] Visible world state: EMPTY/POPULATED
```

### UI mirror
HUD or console panel should also show:
- `World: Descriptor Only`
- `World: Chunks Ready`
- `World: Visible`

### Done condition
The logs and the viewport must say the same thing.

---

## 3. Unreal-like Control Schema for NovaForge Editor

This should be familiar, but kept minimal.

### 3.1 Global editor navigation

| Action | Input |
|---|---|
| orbit camera | hold RMB + move mouse |
| pan camera | hold MMB + move mouse |
| zoom camera | mouse wheel |
| focus selection | F |
| frame dev spawn | Shift+F |
| fast camera move | hold Shift |
| slow camera move | hold Ctrl |
| toggle free-fly mode | RMB + WASD active |
| forward/back/left/right | W A S D while RMB held |
| up/down | Q / E while RMB held |
| reset viewport camera | Home |

### 3.2 Selection and transform

| Action | Input |
|---|---|
| select object | LMB |
| additive select | Ctrl + LMB |
| marquee select | drag LMB in select mode |
| move gizmo | W |
| rotate gizmo | E |
| scale gizmo | R |
| toggle local/world | T |
| duplicate selection | Ctrl + D |
| delete selection | Delete |
| snap toggle | X |
| increase grid snap | ] |
| decrease grid snap | [ |

### 3.3 Editor shell actions

| Action | Input |
|---|---|
| open content browser search | Ctrl + P |
| save dev world | Ctrl + S |
| save all | Ctrl + Shift + S |
| reload dev world | Ctrl + R |
| toggle console | ` |
| play in editor dev world | Alt + P |
| stop play session | Shift + Esc |
| open voxel inspector | Alt + V |
| open model editor | Alt + M |
| open asset editor | Alt + A |

### 3.4 Interaction model rules
- camera navigation only captures movement when the pointer is inside the viewport
- UI panels always win when mouse is over panel chrome or controls
- gizmo drag overrides camera orbit
- content browser and inspector must support keyboard focus traversal
- every destructive action requires visible undo support once history exists

---

## 4. Minimal visual upgrade using current stack

Do not overbuild. Use what exists.

### 4.1 Visual target
A restrained dark industrial editor style.

### 4.2 What to change now

#### Panel chrome
Current colors are flat. Replace with a stronger layered hierarchy.

Recommended palette:
- shell background: `#17181C`
- panel body: `#23252B`
- title bar: `#2B3038`
- title active accent strip: `#4C8DFF`
- border: `#3A3F48`
- text primary: `#D8DEE9`
- text dim: `#8A93A2`
- hover row: `#313845`
- selected row: `#2F5EA8`
- warning: `#D69C2F`
- error: `#C94F4F`
- success: `#4FA36C`

#### Immediate wins
- add 1px accent strip under active title bars
- add inner shadow illusion using a darker top edge and brighter bottom edge
- draw alternating row backgrounds in content browser and console
- give viewport a subtle status bar at the bottom
- draw panel headers in slightly larger text than body labels
- add small monospace-like debug labels through the existing text system by using a lower scale and tighter placement

#### No new renderer features required for these
All can be done with `DrawRect`, `DrawOutlineRect`, and `DrawText`.

### 4.3 Style rules
- no gradients yet
- no transparency-heavy effects yet
- no rounded corners yet
- no icon atlas required yet
- keep every improvement within the current primitive UI renderer

---

## 5. Model Editor definition

### Goal
A dedicated panel or mode for inspecting and assigning model-level data without needing the full runtime game loop.

### What the Model Editor is in Phase 1 and 2
Not a DCC replacement. It is a project-level asset inspector/editor for imported or authored model metadata.

### Supported responsibilities
- preview static mesh or low-poly model
- inspect bounds, pivots, material slots, LOD list
- assign collision preset
- assign gameplay tags or category tags
- assign voxel-wrapper relationship later
- assign thumbnail capture view
- validate scale against project standards

### Model Editor layout
- center: model preview viewport
- left: model hierarchy / submesh list
- right: properties inspector
- bottom: validation and import messages

### Phase 1 usage
The user opens a model from Content Browser.
The Model Editor shows:
- mesh name
- dimensions
- pivot
- material slots
- test preview with orbit camera
- scale mismatch warnings

### Phase 2 usage
The Model Editor adds:
- collision proxy assignment
- voxel interaction flags
- destructibility compatibility flags
- runtime category tags for chunk-attached decorative objects

### User flow
1. user selects a mesh asset in Content Browser
2. double click opens Model Editor
3. preview viewport loads mesh
4. inspector exposes editable metadata
5. save writes sidecar metadata or asset registry entry

### Required file direction
Likely new files:
- `Source/Editor/Panels/ModelEditorPanel.h`
- `Source/Editor/Panels/ModelEditorPanel.cpp`
- `Source/Engine/Assets/ModelAssetMetadata.h`
- `Source/Engine/Assets/ModelAssetMetadata.cpp`

---

## 6. Asset Editor definition

### Goal
A generic editor entry point for asset-specific tooling.

### Role
The Asset Editor is the dispatch layer. It is not one panel. It routes assets to the right editor.

### Asset types and handlers
| Asset Type | Editor |
|---|---|
| folder | content browser navigation |
| mesh/model | model editor |
| material definition | material editor |
| texture | texture inspector |
| world definition | dev world editor |
| voxel save/chunk data | voxel inspector/editor |
| json definition | text/property editor |

### Required interaction contract
```cpp
class IAssetEditor
{
public:
    virtual ~IAssetEditor() = default;
    virtual bool CanOpen(const std::string& path) const = 0;
    virtual void Open(const std::string& path) = 0;
    virtual void Draw(float x, float y, float w, float h) = 0;
    virtual void Save() = 0;
};
```

### Asset Editor manager
Add a small router:
- `AssetEditorManager::Open(path)`
- choose handler by extension or registry type
- reuse an existing editor tab if already open

### Phase 1 minimal supported types
- folders
- `.json` definitions
- model files if available
- textures if available
- `DevWorld.json`

### Phase 2 additions
- chunk save files
- voxel palette definitions
- mining/resource definitions

---

## 7. Dev World editor definition

This is the missing piece for Phase 1 clarity.

### Goal
A dedicated editor surface for the only early sandbox world.

### What it edits
- world id
- world seed
- spawn position
- initial chunk radius
- debug flags
- test lighting/time preset
- save/load path references

### Layout
- viewport in center
- dev world properties on right
- outliner on left
- console and world validation bottom

### User flow
1. editor boots directly into Dev World mode
2. if `DevWorld.json` is missing, fallback defaults are shown in inspector as unsaved state
3. user adjusts seed/spawn/test flags
4. user clicks save or uses `Ctrl+S`
5. world definition writes to `Content/Definitions/DevWorld.json`
6. user reloads world with `Ctrl+R`

### Required immediate UI status text
- `Dev World Config: Loaded / Fallback / Dirty`
- `Chunk Data: N loaded`
- `World Visible: Yes / No`

---

## 8. What Phase 1 should actually mean in this repo

The requested Phase 1 is:

> one stable sandbox world for all early testing

### Phase 1 deliverable mapping against current source

| Deliverable | Current status | Notes |
|---|---|---|
| single dev solar system or dev zone | partial | only a small voxel terrain chunk patch exists in `GameWorld.cpp`; no real authored dev zone yet |
| controlled spawn path | partial | spawn exists in config, but no authored pathing or validation loop |
| fixed test terrain/world seed | partial | seed exists in `DevWorldConfig`; needs save/reload validation and visible confirmation |
| basic camera and movement | partial | editor orbit camera exists; gameplay movement exists separately; not unified in editor play flow |
| editor load path for dev world | partial | editor boot path exists, but visible world readiness is not fully honest |
| save/load hooks for dev world | partial | `WorldSaveLoad` and chunk serializer exist, but not fully wired into editor actions |
| basic world debug visualization | partial | overlays exist, but are mostly console-level or not fully viewport integrated |

### Correct Phase 1 target
By the end of Phase 1 the editor should do this every boot:
1. load or create Dev World definition
2. spawn a visible test world
3. let user orbit and inspect it
4. let user save/reload world definition and chunk state
5. display exact world state and chunk counts

### Phase 1 features to defer
- fleet
- missions
- economy
- advanced material editing
- animation authoring
- non-dev world loading

---

## 9. What Phase 2 should actually mean in this repo

The requested Phase 2 is:

> establish authoritative voxel structure

### Phase 2 deliverable mapping against current source

| Deliverable | Current status | Notes |
|---|---|---|
| chunk data model | present | `Chunk`, `ChunkCoord`, `ChunkMap` exist |
| chunk streaming rules | partial | `ChunkStreamer` exists, but editor/runtime warm-start and validation path are still thin |
| voxel storage and indexing | present | chunk voxel storage exists |
| voxel edit operations | partial | `VoxelEditApi` exists, but editor authoring loop is not fully surfaced |
| voxel damage/mining hooks | partial | mining hooks exist, but not validated in a stable editor/runtime roundtrip |
| voxel save serialization | present/partial | serializer exists, but lifecycle usage needs testing |
| editor voxel inspection and authoring hooks | partial | `VoxelInspector` exists, but full authoring workflow is not proven |
| runtime validation for chunk integrity | partial | debug overlay validation exists, but needs automatic checks and visible reports |

### Correct Phase 2 target
By the end of Phase 2 the repo should support:
- deterministic chunk generation for Dev World
- visible chunk bounds and chunk ids in viewport debug mode
- add/remove voxel operations in editor
- save and reload chunk maps without corruption
- integrity validation after every edit/save/load cycle

### Phase 2 features to defer
- biome diversity
- large-scale solar system content
- procedural world streaming beyond the dev sandbox envelope
- destruction VFX polish

---

## 10. Why none of this feels fully working yet

Because the repo currently mixes:
- structural presence of systems
- partial implementations
- placeholder UI
- optimistic logging

The project needs to stop counting files as completed systems.
A system only counts when the editor loop proves it:
- visible
- editable
- saveable
- reloadable
- validated

That is the actual gap.

---

## 11. Recovery sequence

### Recovery pass A
Stabilize the editor shell.
- implement viewport sub-rect render path
- add clip/scissor stack
- tighten resize propagation
- polish panel chrome and row states

### Recovery pass B
Make Dev World truthful.
- add world boot stages
- add HUD readiness text
- add chunk/mesh/render-visible counters
- wire save/reload into toolbar and shortcuts

### Recovery pass C
Make Phase 1 real.
- one visible Dev World only
- one save path only
- one reload path only
- one debug overlay set only

### Recovery pass D
Make Phase 2 real.
- expose voxel edit actions in viewport or voxel inspector
- save chunk map
- reload chunk map
- run integrity validation and report it in UI

---

## 12. File-level next targets

### Third patch set files
- `Source/UI/Rendering/UIRenderer.h`
- `Source/UI/Rendering/UIRenderer.cpp`
- `Source/Editor/Application/EditorApp.cpp`
- `Source/Editor/Viewport/EditorViewport.h`
- `Source/Editor/Viewport/EditorViewport.cpp`
- `Source/Renderer/RHI/RenderDevice.h`
- `Source/Renderer/RHI/RenderDevice.cpp`
- `Source/Game/World/GameWorld.h`
- `Source/Game/World/GameWorld.cpp`
- `Source/Editor/Panels/HUDPanel.cpp`
- `Source/Editor/Panels/ConsolePanel.cpp`

### Fourth patch set files
- `Source/Editor/Panels/ModelEditorPanel.h`
- `Source/Editor/Panels/ModelEditorPanel.cpp`
- `Source/Editor/Assets/AssetEditorManager.h`
- `Source/Editor/Assets/AssetEditorManager.cpp`
- `Source/Engine/Assets/ModelAssetMetadata.h`
- `Source/Engine/Assets/ModelAssetMetadata.cpp`

---

## 13. Acceptance checklist

### Editor shell
- [ ] viewport renders only inside dock panel
- [ ] panel content is clipped correctly
- [ ] maximize and resize preserve correct layout
- [ ] shell style no longer looks flat or unfinished

### Dev World / Phase 1
- [ ] Dev World visibly loads every boot
- [ ] seed and spawn are shown in UI
- [ ] save and reload work from editor
- [ ] debug overlay reports exact state

### Voxel runtime / Phase 2
- [ ] chunk count visible in UI
- [ ] voxel inspection works against real chunk data
- [ ] voxel edits can be made and reloaded
- [ ] integrity validation reports pass/fail after reload

---

## 14. Final direction

Do not spread effort across more systems yet.

The correct next milestone is:
- make the editor truthful
- make Dev World visible and persistent
- make voxel state authoritative and testable
- make the UI look intentional using only the current renderer

That is enough to turn this from scaffold into a usable foundation.
