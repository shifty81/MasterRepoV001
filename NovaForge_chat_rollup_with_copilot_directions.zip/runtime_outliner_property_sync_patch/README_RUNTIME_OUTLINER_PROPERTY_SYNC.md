# Runtime Chunk Metadata + Property Editing + Viewport Highlight Sync Patch

This patch set adds compile-ready scaffolds for:

- real runtime chunk metadata flowing into the outliner model
- property editing widgets with dirty tracking
- selection synchronization back into viewport highlight state

## Included patch targets

- `Source/Editor/Application/EditorApp.h`
- `Source/Editor/Application/EditorApp.cpp`
- `Source/Editor/Inspector/PropertyInspectorSystem.h`
- `Source/Editor/Inspector/PropertyInspectorSystem.cpp`
- `Source/Editor/Panels/Inspector.h`
- `Source/Editor/Panels/Inspector.cpp`
- `Source/Editor/Panels/WorldOutlinerPanel.h`
- `Source/Editor/Panels/WorldOutlinerPanel.cpp`
- `Source/Editor/Selection/SelectionService.h`
- `Source/Editor/Selection/SelectionService.cpp`
- `Source/Editor/Viewport/EditorViewport.h`
- `Source/Editor/Viewport/EditorViewport.cpp`

## What this patch does

### Runtime chunk metadata into outliner
Adds a chunk metadata structure that can be transformed into outliner nodes with:
- chunk id
- chunk label
- chunk coordinate
- loaded/dirty/meshed flags

### Property editing widgets with dirty tracking
Adds editable property entries with:
- current value
- original value
- dirty flag
- widget hint
- simple edit application helpers

### Selection synchronization back to viewport highlights
Adds viewport highlight state driven from editor selection:
- selected world object id
- selected chunk id
- selected voxel id
- active highlight label

## Important truth

This is a compile-ready scaffold patch.
It sets the ownership and state flow.
It does not yet include:
- real on-screen property widgets
- true runtime chunk feed from live world systems
- real rendered viewport highlight drawing
- undo transaction support
