# COMPILE_READY_PATCH_SET.md

Validated in container by building `NovaForgeEditor` after applying these changes.

## Files included

- `Source/Editor/Application/EditorApp.h`
- `Source/Editor/Application/EditorApp.cpp`
- `Source/Editor/Panels/ContentBrowser.h`
- `Source/Editor/Panels/ContentBrowser.cpp`
- `Source/Editor/Viewport/EditorViewport.cpp`
- `Source/Game/World/GameWorld.cpp`

## `Source/Editor/Application/EditorApp.h`

```diff
--- /tmp/mr_orig/MasterRepo-main/Source/Editor/Application/EditorApp.h	2026-04-02 21:58:58.000000000 +0000
+++ /tmp/mr/MasterRepo-main/Source/Editor/Application/EditorApp.h	2026-04-02 22:18:52.502465567 +0000
@@ -67,6 +67,9 @@
     /// @param dt Elapsed seconds since the previous frame.
     void TickFrame(float dt);
 
+    /// @brief Apply a new client size to all editor subsystems.
+    void HandleResize(int width, int height) noexcept;
+
     DockingSystem  m_DockingSystem;
     SceneOutliner  m_SceneOutliner;
     Inspector      m_Inspector;
```

## `Source/Editor/Application/EditorApp.cpp`

```diff
--- /tmp/mr_orig/MasterRepo-main/Source/Editor/Application/EditorApp.cpp	2026-04-02 21:58:58.000000000 +0000
+++ /tmp/mr/MasterRepo-main/Source/Editor/Application/EditorApp.cpp	2026-04-02 22:18:52.503534591 +0000
@@ -158,6 +158,16 @@
                      suggested->right  - suggested->left,
                      suggested->bottom - suggested->top,
                      SWP_NOZORDER | SWP_NOACTIVATE);
+        HandleResize(suggested->right - suggested->left,
+                     suggested->bottom - suggested->top);
+        break;
+    }
+
+    case WM_SIZE:
+    {
+        const int width  = static_cast<int>(LOWORD(lp));
+        const int height = static_cast<int>(HIWORD(lp));
+        HandleResize(width, height);
         break;
     }
 
@@ -369,6 +379,33 @@
     return true;
 }
 
+
+void EditorApp::HandleResize(int width, int height) noexcept
+{
+    if (width <= 0 || height <= 0)
+        return;
+
+    if (width == m_ClientWidth && height == m_ClientHeight)
+        return;
+
+    m_ClientWidth = width;
+    m_ClientHeight = height;
+
+    if (m_RenderDevice)
+        m_RenderDevice->Resize(m_ClientWidth, m_ClientHeight);
+
+    m_UIRenderer.SetViewportSize(static_cast<float>(m_ClientWidth),
+                                 static_cast<float>(m_ClientHeight));
+    m_UIRenderer.SetDpiScale(m_DpiScale);
+
+    m_Viewport.Resize(m_ClientWidth, m_ClientHeight);
+
+    Logger::Log(LogLevel::Info, "Editor",
+                "Viewport resized: "
+                + std::to_string(m_ClientWidth) + "x"
+                + std::to_string(m_ClientHeight));
+}
+
 void EditorApp::TickFrame(float dt)
 {
     m_RenderDevice->BeginFrame();
@@ -434,20 +471,15 @@
             DispatchMessageW(&msg);
         }
 
-        // Propagate window resize to the viewport
+        // Poll the client rect as a safety net for any resize path that
+        // did not arrive through WM_SIZE.
         {
             RECT rc{};
             if (GetClientRect(static_cast<HWND>(m_Hwnd), &rc))
             {
-                int newW = rc.right  - rc.left;
-                int newH = rc.bottom - rc.top;
-                if (newW != m_ClientWidth || newH != m_ClientHeight)
-                {
-                    m_ClientWidth  = newW;
-                    m_ClientHeight = newH;
-                    m_RenderDevice->Resize(m_ClientWidth, m_ClientHeight);
-                    m_Viewport.Resize(m_ClientWidth, m_ClientHeight);
-                }
+                const int newW = rc.right  - rc.left;
+                const int newH = rc.bottom - rc.top;
+                HandleResize(newW, newH);
             }
         }
 
```

## `Source/Editor/Panels/ContentBrowser.h`

```diff
--- /tmp/mr_orig/MasterRepo-main/Source/Editor/Panels/ContentBrowser.h	2026-04-02 21:58:58.000000000 +0000
+++ /tmp/mr/MasterRepo-main/Source/Editor/Panels/ContentBrowser.h	2026-04-02 22:20:28.023470413 +0000
@@ -1,6 +1,7 @@
 #pragma once
 #include "Editor/Application/EditorInputState.h"
 #include <string>
+#include <vector>
 
 namespace NF { class UIRenderer; }
 
@@ -30,8 +31,20 @@
     [[nodiscard]] const std::string& GetSelectedAsset() const noexcept { return m_SelectedAsset; }
 
 private:
+    struct Entry {
+        std::string DisplayName;
+        std::string FullPath;
+        bool        IsDirectory{false};
+    };
+
+    void RefreshEntries();
+    void NavigateTo(const std::string& path);
+
     std::string             m_RootPath;
+    std::string             m_CurrentPath;
     std::string             m_SelectedAsset;
+    std::vector<Entry>      m_Entries;
+    bool                    m_Dirty{true};
     UIRenderer*             m_Renderer{nullptr};
     const EditorInputState* m_Input{nullptr};
 };
```

## `Source/Editor/Panels/ContentBrowser.cpp`

```diff
--- /tmp/mr_orig/MasterRepo-main/Source/Editor/Panels/ContentBrowser.cpp	2026-04-02 21:58:58.000000000 +0000
+++ /tmp/mr/MasterRepo-main/Source/Editor/Panels/ContentBrowser.cpp	2026-04-02 22:20:28.024159282 +0000
@@ -1,12 +1,63 @@
 #include "Editor/Panels/ContentBrowser.h"
 #include "UI/Rendering/UIRenderer.h"
+#include <algorithm>
+#include <filesystem>
 
 namespace NF::Editor {
+namespace fs = std::filesystem;
 
-void ContentBrowser::Update([[maybe_unused]] float dt) {}
+void ContentBrowser::RefreshEntries()
+{
+    m_Entries.clear();
+
+    if (m_RootPath.empty())
+        return;
+
+    if (m_CurrentPath.empty())
+        m_CurrentPath = m_RootPath;
+
+    std::error_code ec;
+    const fs::path currentPath(m_CurrentPath);
+    if (!fs::exists(currentPath, ec) || !fs::is_directory(currentPath, ec))
+        return;
+
+    for (const fs::directory_entry& entry : fs::directory_iterator(currentPath, ec)) {
+        if (ec) break;
+
+        Entry row{};
+        row.IsDirectory = entry.is_directory(ec);
+        row.FullPath = entry.path().lexically_normal().generic_string();
+        row.DisplayName = entry.path().filename().generic_string();
+        if (row.IsDirectory)
+            row.DisplayName += "/";
+        m_Entries.push_back(std::move(row));
+    }
+
+    std::sort(m_Entries.begin(), m_Entries.end(), [](const Entry& a, const Entry& b) {
+        if (a.IsDirectory != b.IsDirectory)
+            return a.IsDirectory > b.IsDirectory;
+        return a.DisplayName < b.DisplayName;
+    });
+
+    m_Dirty = false;
+}
+
+void ContentBrowser::NavigateTo(const std::string& path)
+{
+    m_CurrentPath = path;
+    m_SelectedAsset.clear();
+    m_Dirty = true;
+}
+
+void ContentBrowser::Update([[maybe_unused]] float dt)
+{
+    if (m_Dirty)
+        RefreshEntries();
+}
 
 void ContentBrowser::Draw(float x, float y, float w, float h) {
     if (!m_Renderer) return;
+    if (m_Dirty) RefreshEntries();
 
     static constexpr uint32_t kTextColor    = 0xB0B0B0FF;
     static constexpr uint32_t kLabelColor   = 0x808080FF;
@@ -18,30 +69,41 @@
     const float padX  = 6.f  * dpi;
     const float scale = 2.f;
 
-    // Helper: draw one clickable row and return whether it was clicked.
     float cy = y + 4.f * dpi;
 
-    // Root path label (non-clickable header)
     const std::string rootLabel = "Root: " + (m_RootPath.empty() ? "(none)" : m_RootPath);
     m_Renderer->DrawText(rootLabel, x + padX, cy, kLabelColor, scale);
     cy += lineH;
 
-    // Entries — simple static list matching the actual content structure.
-    const char* kEntries[] = {
-        "Assets/",
-        "  Definitions/",
-        "  Textures/",
-        "  Models/",
-    };
+    const std::string pathLabel = "Path: " + (m_CurrentPath.empty() ? "(none)" : m_CurrentPath);
+    m_Renderer->DrawText(pathLabel, x + padX, cy, kLabelColor, scale);
+    cy += lineH;
+
+    if (!m_CurrentPath.empty() && m_CurrentPath != m_RootPath) {
+        const bool hovered = m_Input &&
+            m_Input->mouseX >= x && m_Input->mouseX < x + w &&
+            m_Input->mouseY >= cy && m_Input->mouseY < cy + lineH;
+        if (hovered) m_Renderer->DrawRect({x, cy, w, lineH}, kHoverColor);
+        if (hovered && m_Input->leftJustPressed) {
+            NavigateTo(fs::path(m_CurrentPath).parent_path().generic_string());
+            return;
+        }
+        m_Renderer->DrawText("../", x + padX, cy + 2.f * dpi, kTextColor, scale);
+        cy += lineH;
+    }
+
+    if (m_Entries.empty()) {
+        m_Renderer->DrawText("(empty)", x + padX, cy + 2.f * dpi, kLabelColor, scale);
+        return;
+    }
 
-    for (const char* entry : kEntries) {
+    for (const Entry& entry : m_Entries) {
         if (cy + lineH > y + h) break;
 
-        const std::string entryStr(entry);
-        const bool hovered  = m_Input &&
-                              m_Input->mouseX >= x          && m_Input->mouseX < x + w &&
-                              m_Input->mouseY >= cy         && m_Input->mouseY < cy + lineH;
-        const bool selected = (m_SelectedAsset == entryStr);
+        const bool hovered = m_Input &&
+            m_Input->mouseX >= x && m_Input->mouseX < x + w &&
+            m_Input->mouseY >= cy && m_Input->mouseY < cy + lineH;
+        const bool selected = (m_SelectedAsset == entry.FullPath);
 
         if (selected) {
             m_Renderer->DrawRect({x, cy, w, lineH}, kSelectColor);
@@ -50,11 +112,15 @@
         }
 
         if (hovered && m_Input->leftJustPressed) {
-            m_SelectedAsset = entryStr;
+            if (entry.IsDirectory) {
+                NavigateTo(entry.FullPath);
+                return;
+            }
+            m_SelectedAsset = entry.FullPath;
         }
 
         const uint32_t rowColor = selected ? 0xFFFFFFFF : kTextColor;
-        m_Renderer->DrawText(entryStr, x + padX, cy + 2.f * dpi, rowColor, scale);
+        m_Renderer->DrawText(entry.DisplayName, x + padX, cy + 2.f * dpi, rowColor, scale);
         cy += lineH;
     }
 }
```

## `Source/Editor/Viewport/EditorViewport.cpp`

```diff
--- /tmp/mr_orig/MasterRepo-main/Source/Editor/Viewport/EditorViewport.cpp	2026-04-02 21:58:58.000000000 +0000
+++ /tmp/mr/MasterRepo-main/Source/Editor/Viewport/EditorViewport.cpp	2026-04-02 22:18:52.505027643 +0000
@@ -20,8 +20,8 @@
 }
 
 void EditorViewport::Resize(int width, int height) {
-    m_Width  = width;
-    m_Height = height;
+    m_Width  = std::max(width, 1);
+    m_Height = std::max(height, 1);
 }
 
 void EditorViewport::Update([[maybe_unused]] float dt) {
@@ -73,6 +73,8 @@
     m_BoundsY = y;
     m_BoundsW = w;
     m_BoundsH = h;
+    m_Width   = std::max(1, static_cast<int>(w));
+    m_Height  = std::max(1, static_cast<int>(h));
 
     if (!m_Renderer) return;
 
```

## `Source/Game/World/GameWorld.cpp`

```diff
--- /tmp/mr_orig/MasterRepo-main/Source/Game/World/GameWorld.cpp	2026-04-02 21:58:58.000000000 +0000
+++ /tmp/mr/MasterRepo-main/Source/Game/World/GameWorld.cpp	2026-04-02 22:18:52.505310106 +0000
@@ -6,84 +6,80 @@
 
 bool GameWorld::Initialize(const std::string& contentRoot)
 {
-    // Load dev world config
     const std::string configPath = contentRoot + "/Definitions/DevWorld.json";
+    bool usedFallback = false;
     if (!m_Config.LoadFromFile(configPath))
     {
         Logger::Log(LogLevel::Warning, "GameWorld",
                     "DevWorld config not found at " + configPath + "; using defaults");
         m_Config = DevWorldConfig::Defaults();
+        usedFallback = true;
     }
 
-    // Load the level using the world id
-    m_Level.Load(m_Config.WorldId());
-
-    // Log world identity and seed at startup
     Logger::Log(LogLevel::Info, "GameWorld",
-                "World: " + m_Config.WorldId()
-                + " | Seed: " + std::to_string(m_Config.Seed()));
+                "World definition loaded: " + m_Config.WorldId());
+    Logger::Log(LogLevel::Info, "GameWorld",
+                std::string("Fallback definition used: ") + (usedFallback ? "YES" : "NO"));
+    Logger::Log(LogLevel::Info, "GameWorld",
+                "World seed: " + std::to_string(m_Config.Seed()));
+
+    m_Level.Load(m_Config.WorldId());
 
-    // Create a player entity at the spawn point
     auto& world = m_Level.GetWorld();
     m_PlayerEntity = world.CreateEntity();
     Logger::Log(LogLevel::Info, "GameWorld",
                 "Player entity created: " + std::to_string(m_PlayerEntity));
 
-    // Log spawn point
     const auto& sp = m_Config.GetSpawnPoint();
     Logger::Log(LogLevel::Info, "GameWorld",
-                "Spawn point: (" + std::to_string(sp.Position.X) + ", "
+                "Spawn initialized: (" + std::to_string(sp.Position.X) + ", "
                 + std::to_string(sp.Position.Y) + ", "
                 + std::to_string(sp.Position.Z) + ")");
 
-    m_Ready = true;
-    Logger::Log(LogLevel::Info, "GameWorld", "Initialized");
-
-    // --- Phase 4: generate a starter terrain chunk at the spawn point ---
-    // Place a flat ground layer of mixed voxel types so there is visible
-    // geometry in both the editor viewport and the standalone game client.
-    {
-        const auto& spPos = m_Config.GetSpawnPoint().Position;
-        // Create chunks in a small area around spawn.
-        for (int cx = -1; cx <= 1; ++cx) {
-            for (int cz = -1; cz <= 1; ++cz) {
-                ChunkCoord coord{cx, 0, cz};
-                Chunk* chunk = m_ChunkMap.GetOrCreateChunk(coord);
-
-                // Fill the bottom half with terrain.
-                for (uint8_t x = 0; x < kChunkSize; ++x) {
-                    for (uint8_t z = 0; z < kChunkSize; ++z) {
-                        // Height varies by a simple pattern based on position.
-                        const int wx = cx * kChunkSize + x;
-                        const int wz = cz * kChunkSize + z;
-                        const int height = 8 + (wx * 3 + wz * 7) % 5;
-
-                        for (uint8_t y = 0; y < kChunkSize && y < height; ++y) {
-                            VoxelType type;
-                            if (y < 3)
-                                type = VoxelType::Rock;
-                            else if (y < height - 2)
-                                type = VoxelType::Stone;
-                            else if (y == height - 1)
-                                type = VoxelType::Dirt;
-                            else
-                                type = VoxelType::Stone;
-
-                            // Scatter ore veins.
-                            if (y > 2 && y < 8 && ((wx + y * 3 + wz * 5) % 17 == 0))
-                                type = VoxelType::Ore;
+    const int32_t spawnChunkX = static_cast<int32_t>(sp.Position.X) / kChunkSize;
+    const int32_t spawnChunkY = 0;
+    const int32_t spawnChunkZ = static_cast<int32_t>(sp.Position.Z) / kChunkSize;
+
+    int generatedChunks = 0;
+    for (int cx = spawnChunkX - 1; cx <= spawnChunkX + 1; ++cx) {
+        for (int cz = spawnChunkZ - 1; cz <= spawnChunkZ + 1; ++cz) {
+            ChunkCoord coord{cx, spawnChunkY, cz};
+            Chunk* chunk = m_ChunkMap.GetOrCreateChunk(coord);
+
+            for (uint8_t x = 0; x < kChunkSize; ++x) {
+                for (uint8_t z = 0; z < kChunkSize; ++z) {
+                    const int wx = cx * kChunkSize + static_cast<int>(x);
+                    const int wz = cz * kChunkSize + static_cast<int>(z);
+                    const int height = 8 + ((wx * 3 + wz * 7 + static_cast<int>(m_Config.Seed())) % 5 + 5) % 5;
+
+                    for (uint8_t y = 0; y < kChunkSize && y < height; ++y) {
+                        VoxelType type = VoxelType::Stone;
+                        if (y < 3) {
+                            type = VoxelType::Rock;
+                        } else if (y == height - 1) {
+                            type = VoxelType::Dirt;
+                        }
 
-                            chunk->SetVoxel(x, y, z, static_cast<VoxelId>(type));
+                        if (y > 2 && y < 8 && ((wx + static_cast<int>(y) * 3 + wz * 5) % 17 == 0)) {
+                            type = VoxelType::Ore;
                         }
+
+                        chunk->SetVoxel(x, y, z, static_cast<VoxelId>(type));
                     }
                 }
             }
-        }
 
-        Logger::Log(LogLevel::Info, "GameWorld",
-                    "Starter terrain: 9 chunks, " +
-                    std::to_string(m_ChunkMap.ChunkCount()) + " loaded");
+            ++generatedChunks;
+        }
     }
+
+    Logger::Log(LogLevel::Info, "GameWorld",
+                "Initial chunks generated: " + std::to_string(generatedChunks));
+    Logger::Log(LogLevel::Info, "GameWorld",
+                "Chunk map loaded count: " + std::to_string(m_ChunkMap.ChunkCount()));
+
+    m_Ready = true;
+    Logger::Log(LogLevel::Info, "GameWorld", "Initialized");
     return true;
 }
 
@@ -110,8 +106,6 @@
         return false;
     }
 
-    // Collect live entity ids from the ECS world
-    // For Phase 1, we save only the player entity as a proof of concept
     std::vector<uint32_t> entityIds;
     if (m_PlayerEntity != NullEntity)
         entityIds.push_back(m_PlayerEntity);
```
