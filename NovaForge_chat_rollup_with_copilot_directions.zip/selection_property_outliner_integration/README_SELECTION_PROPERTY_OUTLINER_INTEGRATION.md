# Selection + Property + Outliner Integration Patch

This patch set wires:

- `SelectionService` into Content Browser, Viewport, Inspector, and Status Bar
- `PropertyInspectorSystem` to selected object and asset data
- `WorldOutlinerPanel` to DevWorld/chunk state and selection syncing

## Included patch targets

- `Source/Editor/Application/EditorApp.h`
- `Source/Editor/Application/EditorApp.cpp`
- `Source/Editor/Panels/ContentBrowser.h`
- `Source/Editor/Panels/ContentBrowser.cpp`
- `Source/Editor/Panels/Inspector.h`
- `Source/Editor/Panels/Inspector.cpp`
- `Source/Editor/Panels/StatusBarPanel.h`
- `Source/Editor/Panels/StatusBarPanel.cpp`
- `Source/Editor/Panels/WorldOutlinerPanel.h`
- `Source/Editor/Panels/WorldOutlinerPanel.cpp`
- `Source/Editor/Viewport/EditorViewport.h`
- `Source/Editor/Viewport/EditorViewport.cpp`

## Assumptions

This patch assumes you already added these scaffolded systems:
- `SelectionService`
- `PropertyInspectorSystem`
- `WorldOutlinerPanel`
- `StatusBarPanel`
- `EditorToolContext`
- `VoxelPickService`

## What this patch does

### Selection
Creates one editor-owned `SelectionService` and routes changes from:
- Content Browser asset clicks
- Viewport selection clicks
- World Outliner selection clicks

### Inspector
Populates a `PropertyInspectorSystem` from:
- selected asset path/name/type
- selected world object label/id
- selected chunk id
- selected voxel id

### Status bar
Updates status with:
- active world
- active tool
- current selection label
- readiness
- loaded chunk count
- dirty state

### World outliner
Builds a minimal DevWorld tree from loaded chunk count and lets outliner clicks drive selection.

## Important truth

This is a compile-ready integration scaffold.
It establishes ownership and data flow.
It does not yet provide:
- runtime reflection
- real chunk coordinate metadata
- full UI draw code for tree widgets
- real asset DB integration
