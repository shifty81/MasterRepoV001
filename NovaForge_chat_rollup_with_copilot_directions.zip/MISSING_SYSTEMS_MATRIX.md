# MISSING_SYSTEMS_MATRIX.md

## Purpose
This document identifies the remaining systems required to turn the current NovaForge editor from a scaffolded shell into a stable, testable, Phase 1 and Phase 2 development environment.

Scope:
- Editor
- Engine-facing editor systems
- Dev World workflow
- Voxel runtime authoring workflow

Out of scope:
- Atlas Suite
- external AI tooling
- later-phase advanced asset graph editors

---

## Summary

The editor now has:
- path-resolution scaffolds
- command scaffolds
- tool-mode scaffolds
- viewport clipping/sub-rect scaffolds
- content browser and inspector wiring improvements

The editor still lacks the core glue that makes those systems truthful and usable:
- real world file services
- real hotkey dispatch
- real status strip
- real voxel hit testing
- real dirty/rebuild/save loop
- real asset editor routing
- true executable-path resolution on Windows

---

## Priority Matrix

| Priority | System | Status | Why It Matters | Blocking |
|---|---|---:|---|---:|
| P0 | ProjectPathService hardening | Partial | Current path resolution still depends on `current_path()` fallback | Yes |
| P0 | WorldFileService | Missing | No real world open/save/reload implementation | Yes |
| P0 | DevWorldSerializer | Missing | No real serialization contract for DevWorld | Yes |
| P0 | Real viewport camera/world binding | Partial | Current viewport integration still uses scaffold placeholders | Yes |
| P0 | VoxelPickService real raymarch | Missing | Voxel tools are not real without actual picking | Yes |
| P0 | Chunk dirty/rebuild loop | Missing | Voxel edits cannot update visible world | Yes |
| P1 | EditorHotkeyMap | Missing | Command layer is incomplete without keyboard dispatch | No |
| P1 | Menu/toolbar rendering pass | Partial | Commands exist but full user-facing shell is incomplete | No |
| P1 | StatusBarPanel | Missing | Too much state is hidden in logs | No |
| P1 | Honest world readiness UI | Partial | Console improved, but shell still needs visible truth reporting | No |
| P1 | AssetEditorManager | Missing | Content Browser cannot open real asset editors cleanly | No |
| P2 | Undo/redo transaction base | Missing | Tool logic will become harder to maintain without it | No |
| P2 | Chunk integrity validation UI | Missing | Phase 2 validation remains hidden or absent | No |
| P2 | Better empty/failure states | Partial | Debugging and UX still weaker than needed | No |

---

## Detailed Missing Systems

### 1. ProjectPathService hardening
**Current state:** scaffolded, but still uses `current_path()` as the fallback executable directory guess.

**Missing pieces**
- Win32 executable path query
- repo-root walk from executable directory
- optional CLI override for repo root
- explicit boot failure if manifest cannot be found
- boot log for executable path, repo root, manifest path, content root, DevWorld path

**Why this matters**
Without true path resolution, editor boot can still fail depending on how Visual Studio launches the process.

**Definition of done**
- editor and game resolve project files from executable location, not working directory
- manifest and DevWorld existence are logged clearly
- invalid project root produces explicit UI/log error

---

### 2. WorldFileService
**Current state:** missing.

**Required responsibilities**
- open world file
- save current world
- save world as
- reload world
- report active world path
- integrate with dirty-state tracking

**Likely files**
- `Source/Game/World/WorldFileService.h`
- `Source/Game/World/WorldFileService.cpp`

**Blocking because**
Menu and toolbar commands currently have no real world persistence behind them.

**Definition of done**
- `World.LoadDevWorld`
- `World.SaveDevWorld`
- `World.SaveDevWorldAs`
- `World.ReloadDevWorld`
all execute real file operations

---

### 3. DevWorldSerializer
**Current state:** missing.

**Required responsibilities**
- load `DevWorld.json`
- serialize editable world state
- preserve world metadata and test-seed data
- support strict schema validation
- preserve compatibility with fixed test world workflow

**Likely files**
- `Source/Game/World/DevWorldSerializer.h`
- `Source/Game/World/DevWorldSerializer.cpp`

**Definition of done**
- world opens from disk
- edits can be saved back
- reload reproduces saved world state

---

### 4. Real viewport camera/world binding
**Current state:** scaffold placeholders exist.

**Missing pieces**
- actual editor camera reference
- actual game world reference
- true viewport-local mouse coordinates
- correct docked viewport rect source
- real tool-to-world interaction path

**Why this matters**
Until real objects are bound, voxel tools remain structurally wired but non-functional.

---

### 5. VoxelPickService real implementation
**Current state:** service exists as stub only.

**Missing pieces**
- convert mouse to viewport-local coordinates
- build camera ray
- traverse chunk storage
- find first solid voxel
- compute hit face normal
- compute adjacent placement cell
- return reliable hit result

**Definition of done**
- inspect mode can identify voxels
- add mode can place voxels correctly
- remove mode can target voxels correctly

---

### 6. Chunk dirty/rebuild loop
**Current state:** missing.

**Required behavior**
- mark changed chunk dirty
- rebuild mesh for dirty chunk
- upload mesh to renderer
- refresh viewport
- set world dirty flag
- update inspector/debug stats

**Why this matters**
Even with correct voxel picking, edits will appear broken unless the changed chunk visibly updates.

---

### 7. EditorHotkeyMap
**Current state:** missing.

**Required behavior**
- map key chords to command IDs
- dispatch through `EditorCommandRegistry`
- respect text-input focus
- support global shell commands
- support tool mode switching

**Minimum hotkeys**
- `Ctrl+S` save
- `Ctrl+Shift+S` save as
- `Ctrl+R` reload
- `Q` select
- `1` inspect
- `2` add
- `3` remove
- backtick toggle console

---

### 8. Menu/toolbar rendering
**Current state:** definitions exist, but full draw/click UX is not complete.

**Missing pieces**
- menu bar draw pass
- menu dropdown state
- toolbar row draw pass
- command enable/disable visuals
- active tool highlight
- tooltips

**Why this matters**
The command shell is only partially visible to the user.

---

### 9. StatusBarPanel
**Current state:** missing.

**Should display**
- active world name
- active tool
- dirty state
- current selection summary
- world readiness
- optional chunk count

**Why this matters**
The editor currently hides too much truth in logs.

---

### 10. AssetEditorManager
**Current state:** missing.

**Required behavior**
- route asset open actions by type
- open/focus editor tabs
- track open editors
- route save/revert
- manage editor-per-asset lifetime

**Depends on**
- Content Browser selection/open actions
- real dock tab management

---

### 11. Undo/redo transaction model
**Current state:** missing.

**Minimum use cases**
- voxel add
- voxel remove
- world property edits
- later asset-property edits

**Why this matters**
Editing systems become fragile if mutation happens without transactions.

---

## Phase Alignment

### Phase 1 — Dev World Only
Still required to claim this phase works:
- real path resolution
- real DevWorld load/reload/save
- visible truthful world state
- stable spawn and reload loop
- world debug readouts in shell
- one stable sandbox workflow

### Phase 2 — Voxel Runtime Only
Still required to claim this phase works:
- real voxel pick
- inspect/add/remove modes
- chunk dirty/rebuild loop
- world dirty/save loop
- chunk integrity validation entry point
- editor-facing voxel authoring hooks

---

## Recommended Execution Order

1. Harden `ProjectPathService`
2. Implement `WorldFileService`
3. Implement `DevWorldSerializer`
4. Bind real camera/world into `EditorViewport`
5. Implement real `VoxelPickService`
6. Add chunk dirty/rebuild loop
7. Add `EditorHotkeyMap`
8. Add `StatusBarPanel`
9. Finish menu/toolbar rendering
10. Add `AssetEditorManager`
11. Add undo/redo base

---

## Keep / Build / Defer

### Keep
- `EditorCommandRegistry`
- `MenuBarPanel`
- `ToolbarPanel`
- `EditorToolContext`
- `ProjectPathService` concept
- viewport sub-rect and clip/scissor work
- content browser and inspector wiring direction

### Build next
- `WorldFileService`
- `DevWorldSerializer`
- `EditorHotkeyMap`
- `StatusBarPanel`
- real `VoxelPickService`
- chunk dirty/rebuild loop

### Defer until after truth/glue systems
- advanced asset editors
- full model/material tool polish
- broad world editing feature expansion
- heavy visual styling passes

---

## Blunt assessment

The repo is no longer missing vision. It is missing the last group of systems that turn command shell, viewport shell, and world shell into one truthful editor.

The real chain that still must be completed is:

**project path truth -> world file truth -> viewport interaction truth -> voxel edit truth -> visible saved truth**

Until that chain is complete, the editor can look more complete than it actually is.

---

## Definition of done for this matrix

This matrix is resolved when:
- boot finds the project reliably
- DevWorld can load, reload, and save for real
- viewport is bound to real runtime objects
- voxel tools work visibly
- edits rebuild chunks and save correctly
- hotkeys work
- status bar reports truth
- asset editing can route cleanly
