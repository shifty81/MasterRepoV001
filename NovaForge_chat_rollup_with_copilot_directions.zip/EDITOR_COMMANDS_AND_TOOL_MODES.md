# EDITOR_COMMANDS_AND_TOOL_MODES.md

## Purpose
This document defines the command system, tool modes, menu model, toolbar model, and input routing contract for the NovaForge standalone editor.

Scope:
- Editor
- Engine-facing editor hooks
- Dev World workflow
- Voxel authoring workflow

Out of scope:
- Atlas Suite
- AI tooling
- external pipeline automation
- later-phase material graph or animation graph editors

---

## Goals

The editor command and tool layer must:

- provide a real top-level shell instead of a passive UI mockup
- unify menu commands, toolbar buttons, hotkeys, and contextual actions behind one command registry
- separate camera navigation from editing tools
- support a stable Dev World workflow first
- support voxel inspect and voxel edit workflow next
- allow asset-type-specific editors to open in a controlled, Unreal-like way

---

## Core Principles

1. One command name per action.
2. Menus, toolbar, hotkeys, and context menus all call the same command.
3. One active editor tool mode at a time.
4. Camera navigation is an override state, not a primary tool.
5. Asset opening is routed by asset type through `AssetEditorManager`.
6. Dev World is a first-class editor target.
7. Voxel authoring must be visible, explicit, and reversible.

---

## Top-Level Editor Shell

The editor must expose a real shell with:

- Menu bar
- Toolbar
- Status bar
- Center workspace tabs
- Left content browser
- Right inspector
- Bottom console/log panel
- HUD overlays inside the viewport

### Default layout

- Top: `MenuBarPanel`
- Below top: `ToolbarPanel`
- Left: `ContentBrowserPanel`
- Center: `ViewportPanel` plus dockable editor tabs
- Right: `InspectorPanel`
- Bottom: `ConsolePanel`
- Bottom status strip: current world, active tool, dirty state, selection summary

---

## Command System

### Required system types

- `EditorCommandRegistry`
- `EditorCommand`
- `EditorCommandContext`
- `EditorHotkeyMap`
- `EditorToolContext`

### Minimal type contract

```cpp
struct EditorCommandContext
{
    EditorApp* app = nullptr;
    GameWorld* world = nullptr;
    InspectorPanel* inspector = nullptr;
    ContentBrowserPanel* contentBrowser = nullptr;
    ConsolePanel* console = nullptr;
};
```

```cpp
struct EditorCommand
{
    std::string id;
    std::string displayName;
    std::function<bool(const EditorCommandContext&)> canExecute;
    std::function<void(EditorCommandContext&)> execute;
};
```

```cpp
class EditorCommandRegistry
{
public:
    void Register(EditorCommand command);
    bool CanExecute(const std::string& id) const;
    bool Execute(const std::string& id);
};
```

### Command ID rules

Use stable string IDs.

Examples:
- `File.NewWorld`
- `File.OpenWorld`
- `File.SaveWorld`
- `World.LoadDevWorld`
- `World.SaveDevWorld`
- `World.ReloadDevWorld`
- `Tools.SelectMode`
- `Tools.VoxelInspectMode`
- `Tools.VoxelAddMode`
- `Tools.VoxelRemoveMode`
- `View.ToggleConsole`
- `View.ToggleInspector`

These IDs are the source of truth for:
- menu items
- toolbar buttons
- hotkeys
- context menu actions
- optional scripting later

---

## Menu Bar Specification

### File
Required commands:
- New World
- Open World
- Save World
- Save World As
- Recent Worlds
- Exit

Command IDs:
- `File.NewWorld`
- `File.OpenWorld`
- `File.SaveWorld`
- `File.SaveWorldAs`
- `File.Exit`

### Edit
Required commands:
- Undo
- Redo

Deferred:
- Duplicate
- Delete
- Preferences

Command IDs:
- `Edit.Undo`
- `Edit.Redo`

### View
Required commands:
- Reset Layout
- Toggle Console
- Toggle Content Browser
- Toggle Inspector
- Toggle Voxel Debug
- Toggle World Debug

Command IDs:
- `View.ResetLayout`
- `View.ToggleConsole`
- `View.ToggleContentBrowser`
- `View.ToggleInspector`
- `View.ToggleVoxelDebug`
- `View.ToggleWorldDebug`

### World
Required commands:
- Load DevWorld
- Reload DevWorld
- Save DevWorld
- Save DevWorld As
- World Settings
- Validate World State

Command IDs:
- `World.LoadDevWorld`
- `World.ReloadDevWorld`
- `World.SaveDevWorld`
- `World.SaveDevWorldAs`
- `World.OpenSettings`
- `World.ValidateState`

### Tools
Required commands:
- Select Mode
- Voxel Inspect
- Voxel Add
- Voxel Remove
- Open Model Editor
- Open Asset Editor for Selection

Command IDs:
- `Tools.SelectMode`
- `Tools.VoxelInspectMode`
- `Tools.VoxelAddMode`
- `Tools.VoxelRemoveMode`
- `Tools.OpenModelEditor`
- `Tools.OpenSelectedAssetEditor`

### Help
Required commands:
- About
- Editor Controls

Command IDs:
- `Help.About`
- `Help.Controls`

---

## Toolbar Specification

The toolbar is not a second command system. It is just a visual launcher for registered commands.

### Required toolbar groups

#### File group
- Save World
- Reload DevWorld

#### Mode group
- Select
- Voxel Inspect
- Voxel Add
- Voxel Remove

#### World group
- Toggle World Debug
- Validate World
- World Settings

#### Asset group
- Open Asset
- Open Model Editor

### Required behavior
- current tool button remains visibly active
- disabled commands appear disabled
- hover tooltip shows command name and hotkey
- toolbar icons can be simple text or glyph placeholders in Phase 1

---

## Hotkey Map

### Global hotkeys
- `Ctrl+S` → `World.SaveDevWorld`
- `Ctrl+Shift+S` → `World.SaveDevWorldAs`
- `Ctrl+O` → `File.OpenWorld`
- `Ctrl+R` → `World.ReloadDevWorld`
- `Ctrl+Z` → `Edit.Undo`
- `Ctrl+Y` → `Edit.Redo`

### Tool hotkeys
- `Q` → `Tools.SelectMode`
- `1` → `Tools.VoxelInspectMode`
- `2` → `Tools.VoxelAddMode`
- `3` → `Tools.VoxelRemoveMode`

### View hotkeys
- `` ` `` → `View.ToggleConsole`
- `F1` → `Help.Controls`

### Asset hotkeys
- `Enter` on selected asset → `Tools.OpenSelectedAssetEditor`

---

## Tool Mode System

### Required enum

```cpp
enum class EditorToolMode
{
    Select,
    VoxelInspect,
    VoxelAdd,
    VoxelRemove
};
```

### Required state object

```cpp
struct EditorToolContext
{
    EditorToolMode activeMode = EditorToolMode::Select;
    bool cameraNavigationActive = false;
    bool worldDirty = false;
};
```

### Rules
- only one active tool mode at a time
- camera navigation is temporary and overrides edit input while active
- toolbar, menu, and hotkey changes must update the same `activeMode`
- HUD must display active tool name

---

## Input Routing Contract

Viewport input must be processed in this order:

1. Confirm mouse is inside viewport content rect.
2. If right mouse held or Alt navigation active, route to camera navigation.
3. Else if a modal or drag operation owns input, continue that operation.
4. Else dispatch by active tool mode.
5. If tool mode consumes click, do not fall through to selection.

### Pseudocode

```cpp
void EditorViewport::HandleInput(const InputState& input)
{
    if (!IsMouseInsideViewport(input.mousePosition))
        return;

    if (input.rightMouseDown || input.altHeld)
    {
        BeginOrContinueCameraNavigation(input);
        return;
    }

    switch (toolContext_.activeMode)
    {
        case EditorToolMode::Select:
            HandleSelectionInput(input);
            break;
        case EditorToolMode::VoxelInspect:
            HandleVoxelInspectInput(input);
            break;
        case EditorToolMode::VoxelAdd:
            HandleVoxelAddInput(input);
            break;
        case EditorToolMode::VoxelRemove:
            HandleVoxelRemoveInput(input);
            break;
    }
}
```

---

## Camera Navigation Schema

Target behavior should feel familiar to Unreal-style editor navigation while staying simple.

### Required navigation
- RMB hold + mouse move: look around
- WASD while RMB held: fly camera
- Mouse wheel: adjust camera speed or dolly
- Shift while navigating: speed boost
- F on selection later: focus target

### Rules
- camera navigation temporarily suppresses edit actions
- tool mode does not change when navigating
- releasing navigation returns control to current tool mode

---

## Selection Mode

### Purpose
Default interaction mode for:
- selecting entities later
- selecting asset-linked scene objects later
- selecting debug world objects
- selecting chunks or world nodes if no voxel mode is active

### Phase 1 behavior
- click empty space clears selection
- click visible debug object or test actor selects it
- inspector shows current selection
- HUD shows selection summary

---

## Voxel Inspect Mode

### Purpose
Read-only voxel interrogation mode.

### Required behavior
- hover raycasts into voxel world
- current hit voxel is highlighted
- inspector displays:
  - chunk coordinate
  - voxel coordinate
  - voxel type
  - damage/integrity if present
  - world position
- left click selects voxel or chunk
- no world modification occurs

### Required feedback
- hover box
- chunk/voxel text in HUD
- invalid hit state if no voxel is under cursor

---

## Voxel Add Mode

### Purpose
Place voxels into the world.

### Required behavior
- use voxel pick hit normal to compute adjacent placement cell
- left click places currently selected voxel type
- placement marks chunk dirty
- dirty chunk rebuilds mesh
- world dirty flag becomes true
- inspector updates if selection follows placement

### Deferred
- brush size
- paint masks
- fill tool
- slope tool

---

## Voxel Remove Mode

### Purpose
Remove or damage voxels from the world.

### Required behavior
- hover highlights targeted voxel
- left click removes voxel or applies damage hook
- changed chunk is marked dirty
- mesh rebuild occurs
- world dirty flag becomes true

### Integration note
If mining systems exist later, this mode can route through mining hooks instead of direct deletion.

---

## Voxel Picking Contract

### Required service
- `VoxelPickService`

### Minimal API

```cpp
struct VoxelPickResult
{
    bool hit = false;
    Int3 chunkCoord {};
    Int3 voxelCoord {};
    Int3 adjacentVoxelCoord {};
    Vec3 worldPosition {};
    Vec3 normal {};
    float distance = 0.0f;
};
```

```cpp
class VoxelPickService
{
public:
    VoxelPickResult PickVoxel(
        const Camera& camera,
        const Rect& viewportRect,
        const Vec2& mousePosition,
        const GameWorld& world) const;
};
```

### Required steps
1. convert mouse from screen space to viewport-local space
2. convert viewport-local position to normalized device coordinates
3. build a world ray from editor camera
4. traverse voxel grid
5. return first solid hit
6. derive adjacent placement coordinate from hit normal

---

## Asset Opening Model

### AssetEditorManager
`AssetEditorManager` is not a visible permanent panel.

It is a service/controller that:
- receives asset open requests
- routes by asset type
- focuses an existing editor tab or creates one
- tracks open asset editor instances
- routes save/revert for open asset editors

### Open triggers
- double click asset in content browser
- press Enter on selected asset
- click toolbar open command
- execute `Tools.OpenSelectedAssetEditor`

### Routing table
- model asset → `ModelEditorPanel`
- world asset → `DevWorldEditorPanel` later
- voxel asset → `VoxelAssetEditorPanel` later
- texture asset → `TextureViewerPanel` later

---

## ModelEditorPanel

### Visibility
Visible only when a model asset is opened.

### Docking target
Open as a center workspace tab.

### Phase 1 minimum contents
- model preview viewport
- mesh stats
- bounds and pivot
- material slot list
- source path or asset path
- simple orbit controls

### User flow
1. select model asset in content browser
2. open asset
3. `AssetEditorManager` routes to `ModelEditorPanel`
4. model editor opens in center tab stack
5. user inspects scale, bounds, slots, and preview

---

## DevWorld Save/Load Commands

### Required services
- `WorldFileService`
- `DevWorldSerializer`

### Command behavior

#### `World.LoadDevWorld`
- unload current transient world state if needed
- load fixed DevWorld asset
- bootstrap chunk generation
- refresh viewport and debug state
- log truthful world status

#### `World.ReloadDevWorld`
- discard transient unsaved runtime state
- reload current DevWorld from disk
- rebuild chunk and debug state

#### `World.SaveDevWorld`
- serialize current world definition and editable runtime data
- clear dirty flag on success
- log output path and result

#### `World.SaveDevWorldAs`
- serialize to chosen alternate path
- update active world path if desired by design
- clear dirty flag on success if current world switched

### Required UI hooks
These commands must be accessible from:
- File menu
- World menu
- toolbar
- hotkeys

---

## Honest Editor State Reporting

### Status bar must show
- active world name
- active tool mode
- dirty state
- current selection summary
- world readiness summary

### HUD must show
- viewport mode
- world bootstrap state
- chunk counts if enabled
- current voxel hit info if voxel mode active

### Console must separate milestones
Correct examples:
- `World definition loaded: DevWorld`
- `Fallback used: yes`
- `Spawn initialized: x,y,z`
- `Chunks generated: N`
- `Chunks meshed: N`
- `Viewport state: populated`

Bad example:
- `Loaded level: DevWorld`
when the viewport is still empty

---

## Minimal Visual Upgrade Using Current UI

Without changing frameworks, the shell can look better with:

- stronger top menubar band
- compact toolbar band below it
- clearer panel headers
- alternating row fills in content browser
- selected tab accent
- active tool button highlight
- subtle borders between dock regions
- status bar strip at bottom
- improved empty-state text for panels
- icon placeholders using simple glyphs or text badges

### Visual rules
- center viewport must remain visually dominant
- interactive states must be obvious
- selected tool must always be readable
- empty/unimplemented states must say so directly

---

## Required New Types

Add these next:

- `Source/Editor/Commands/EditorCommandRegistry.h`
- `Source/Editor/Commands/EditorCommandRegistry.cpp`
- `Source/Editor/Commands/EditorHotkeyMap.h`
- `Source/Editor/Commands/EditorHotkeyMap.cpp`
- `Source/Editor/Panels/MenuBarPanel.h`
- `Source/Editor/Panels/MenuBarPanel.cpp`
- `Source/Editor/Panels/ToolbarPanel.h`
- `Source/Editor/Panels/ToolbarPanel.cpp`
- `Source/Editor/Tools/EditorToolContext.h`
- `Source/Editor/Tools/VoxelPickService.h`
- `Source/Editor/Tools/VoxelPickService.cpp`
- `Source/Editor/Tools/VoxelToolController.h`
- `Source/Editor/Tools/VoxelToolController.cpp`
- `Source/Editor/Assets/AssetEditorManager.h`
- `Source/Editor/Assets/AssetEditorManager.cpp`
- `Source/Editor/Panels/ModelEditorPanel.h`
- `Source/Editor/Panels/ModelEditorPanel.cpp`
- `Source/Game/World/WorldFileService.h`
- `Source/Game/World/WorldFileService.cpp`
- `Source/Game/World/DevWorldSerializer.h`
- `Source/Game/World/DevWorldSerializer.cpp`

---

## Execution Order

1. Add `EditorCommandRegistry`
2. Add `EditorToolContext`
3. Add `MenuBarPanel`
4. Add `ToolbarPanel`
5. Register world and tool commands
6. Bind toolbar and menu to same commands
7. Add `VoxelPickService`
8. Route viewport input by active tool mode
9. Add `AssetEditorManager`
10. Add `ModelEditorPanel`
11. Add world save/load services
12. Add status bar and HUD truth reporting

---

## Phase Alignment

### Phase 1 — Dev World Only
This command/tool system enables:
- real world load path
- real save/load UI
- stable fixed test world workflow
- controlled user interaction
- honest runtime feedback
- basic world debug control

### Phase 2 — Voxel Runtime Only
This command/tool system enables:
- voxel inspect
- voxel add/remove
- chunk dirty/rebuild workflow
- voxel authoring hooks in editor
- chunk integrity validation entry points

---

## Definition of Done

This document is implemented when:

- menu bar exists and works
- toolbar exists and works
- menu, toolbar, and hotkeys call the same commands
- tool mode changes are centralized
- viewport input obeys tool routing rules
- DevWorld save/load commands are callable
- voxel inspect/add/remove modes function
- asset open routing works through `AssetEditorManager`
- model assets open in `ModelEditorPanel`
- status bar and HUD report true editor state

---

## Summary

The editor needs a real command shell, not more passive panels.

The correct structure is:
- one command registry
- one active tool mode
- one viewport input routing contract
- one asset routing service
- one truthful editor state model

That is the shortest path from scaffold to usable development environment.
