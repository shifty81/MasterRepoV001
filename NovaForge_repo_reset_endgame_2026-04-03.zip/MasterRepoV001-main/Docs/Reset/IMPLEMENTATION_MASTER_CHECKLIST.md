# Implementation Master Checklist

## Direction Lock
- [ ] README matches standalone native C++ NovaForge direction
- [ ] Roadmap matches current milestone reality
- [ ] Atlas Suite language removed from active docs
- [ ] WPF language removed from active docs
- [ ] mega-monorepo language removed from active docs

## Archive Hygiene
- [ ] duplicate audit docs moved to Archive/_superseded_docs
- [ ] old reset payloads moved to Archive/_old_reset_payloads
- [ ] error dumps isolated
- [ ] stale source paths moved to Archive/_stale_source

## Editor Trust Layer
- [ ] EditorCommandHistory authoritative
- [ ] VoxelAddCommand implemented
- [ ] VoxelRemoveCommand implemented
- [ ] PropertyEditCommand implemented where needed
- [ ] Undo wired to command history
- [ ] Redo wired to command history
- [ ] toolbar buttons honor CanExecute state
- [ ] menu items honor CanExecute state

## Inspector
- [ ] selected voxel fields visible
- [ ] selected voxel type editable
- [ ] change writes into world state
- [ ] change participates in undo/redo
- [ ] dirty state updates after edit

## Persistence
- [ ] EditorWorldSession created or hardened
- [ ] save command writes dev world
- [ ] reload command reloads same dev world
- [ ] round-trip smoke test added
- [ ] world dirty flag resets correctly after save

## Viewport and World Truth
- [ ] one authoritative viewport implementation remains active
- [ ] stale viewport implementation archived
- [ ] viewport-local picking validated
- [ ] outliner represents real world state
- [ ] selection service reflects chunk/entity/voxel truth

## Boot and Output
- [ ] editor boots cleanly from normal build output
- [ ] game boots cleanly from normal build output
- [ ] Launch Game path documented and stabilized
- [ ] project paths resolved through one service
- [ ] output directory structure normalized

## Minimum Usability
- [ ] docking persistence works
- [ ] resize behavior stable
- [ ] maximize behavior stable
- [ ] minimum readable font/theme pass complete
- [ ] command feedback visible in status/log

## Validation
- [ ] voxel select works
- [ ] voxel add works
- [ ] voxel remove works
- [ ] undo works
- [ ] redo works
- [ ] save works
- [ ] reload works
- [ ] standalone game reflects saved state
